/*
 * OFFIZIEL
 * Viet-Hoang Pham
 * Marius Maier
 * 
 */



package info2.tree;


// ----------------------------------------------------------------
// Exercise 1 (a)
// ----------------------------------------------------------------

public class BinaryTreeNode <K extends Comparable<K>, V>  {
    K key;
    V item;
    
    public BinaryTreeNode <K, V> left;
    public BinaryTreeNode <K, V> right;
    
    public BinaryTreeNode(final K key, final V item) {
        this.key = key;
        this.item = item;
        this.left = null;
        this.right = null;
    }
    
    public BinaryTreeNode(
        final K key,
        final V item,
        final BinaryTreeNode <K, V> left,
        final BinaryTreeNode <K, V> right
    ) {
    	this.key = key;
        this.item = item;
        this.left = left;
        this.right = right;
    }
    
    
    /*
     * Zusätzliche getter und setter für die Arbeit mit Baumknoten/ Bäumen
     */
    
    public K getKey() {
        return key;
    }

    public void setKey(K key) {
        this.key = key;
    }

    public V getItem() {
        return item;
    }

    public void setItem(V item) {
        this.item = item;
    }

    public BinaryTreeNode<K, V> getLeft() {
        return left;
    }

    public void setLeft(BinaryTreeNode<K, V> left) {
        this.left = left;
    }

    public BinaryTreeNode<K, V> getRight() {
        return right;
    }

    public void setRight(BinaryTreeNode<K, V> right) {
        this.right = right;
    }
}
    
