/*
 * OFFIZIEL
 * Viet-Hoang Pham
 * Marius Maier
 * 
 */

package info2.tree;


// ----------------------------------------------------------------
// Exercise 1 (b) -- general class structure
// ----------------------------------------------------------------

public class BinaryTree<K extends Comparable<K>, V> {
 /**   
  * Konvertierung von int zu generischen Typen
  * In den Aufgaben benutze ich von mir zusätzlich erstellte getter und setter Methoden aus Klasse "BinaryTreeNode"
  */
    private BinaryTreeNode<K, V> root;
    
    public BinaryTree() {
        this.root = null;
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (c)
    // ----------------------------------------------------------------
    
    /**
     * HelperMethode für insertSorted
     * @param node
     * @param key
     * @param item
     * 
     */
    private BinaryTreeNode<K, V> insertSortedHelper(
        final BinaryTreeNode<K, V> node,
        final K key,
        final V item
    ) {
        if (node == null) {
            return new BinaryTreeNode<K, V>(key, item);
        }
        
         int compareKeyInt = key.compareTo(node.getKey());
        
        if (compareKeyInt < 0) {
        	node.setLeft(insertSortedHelper(node.getLeft(), key, item));
        } else if (compareKeyInt > 0) {
        	node.setRight(insertSortedHelper(node.getRight(), key, item));
        }
        else {
        	node.setItem(item);
        }
        return node ;
        
    }
    /**
     * Methode sortiert ein übergebenen Schlüssel (und das entsprechende Element) an die richtige Stelle im Baum
     * @param key
     * @param item
     * @return neuer Baum mit eingefügtem Schlüssel/Wert
     */
    public void insertSorted(final K key, final V item) {
        this.root = insertSortedHelper(this.root, key, item);
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (d)
    // ----------------------------------------------------------------

    private BinaryTreeNode<K, V> minNode(final BinaryTreeNode<K, V> ptr) {
        if (ptr == null) { 
            return null;
        } else if (ptr.getLeft() == null) {
            return ptr;
        } else {
            return minNode(ptr.getLeft());
        }
    }
    
    
    /**
     * HelperMethode für removeSorted
     * @param ptr 
     * @param key
     * @return bearbeiteter Baum
     */
    private BinaryTreeNode<K, V> removeSortedHelper(
    		BinaryTreeNode<K, V> ptr,
    		K key
    	) {
        if (ptr == null ) {
            return null;
        }
        int compareKeyInt = key.compareTo(ptr.getKey());
        
        if (compareKeyInt < 0) {
        	  ptr.setLeft(removeSortedHelper(ptr.getLeft(), key));
           
        } else if (compareKeyInt > 0) {
        	ptr.setRight(removeSortedHelper(ptr.getRight(), key));
          
        } else {
            if (ptr.getLeft() == null && ptr.getRight() == null) {
                return null;
                
            } else if (ptr.getRight() == null) {
               return ptr.getLeft();
               
            } else if (ptr.getLeft() == null) {
               return ptr.getRight();
               
            } else {
             
            	BinaryTreeNode<K, V> minNode = minNode(ptr.getRight());
                K minValue = minNode.getKey();
                ptr.setRight(removeSortedHelper(ptr.getRight(), minValue));
                ptr.setKey(minValue);
            }
        }
        return ptr;
    }
    
    /**
     * Methode zum Entfernen eines Schlüssels im Baum
     * @param key Schlüssel
     */
    public void removeSorted(final K key) {
        this.root = removeSortedHelper(this.root, key);
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (e)
    // ----------------------------------------------------------------
    
    private int heightHelper(BinaryTreeNode<K, V> ptr) {
        if (ptr == null) {
            return 0;
        }
        return 1 + Math.max(heightHelper(ptr.getLeft()), heightHelper(ptr.getRight()));
    }
/**
 * Methode für Höhe eines Baums
 * @return Höhe des Baums
 */
    public int height() {
        return heightHelper(this.root);
    }
    
    private int balanceFactor(BinaryTreeNode<K, V> ptr) {
        if (ptr == null) {
            return 0;
        }
        return heightHelper(ptr.getRight()) - heightHelper(ptr.getLeft());
    }

    private boolean isBalancedHelper(BinaryTreeNode<K, V> ptr) {
        if (ptr == null) {
            return true;
        }
        return isBalancedHelper(ptr.getLeft()) && isBalancedHelper(ptr.getRight())
                && Math.abs(balanceFactor(ptr)) <= 1;
    }
    /**
     * Methode für Balanciertheit eines Baumes
     * @return ob Baum balanciert ist
     */
    public boolean isBalanced() {
        return isBalancedHelper(this.root);
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (g)
    // ----------------------------------------------------------------

    /**
     * Sucht nach dem Schlüssel "key" im Baum
     * @param key
     * @return zum Schlüssel dazugehörigen Datenwert
     */
    public V get(final K key) {
        BinaryTreeNode<K, V> node = getNode(key);
        if (node != null) {
            return node.getItem();
        }
        return null;
    }

    /**
     * HelperMethode für einen sortierten Baum zur schnelleren Suche
     * @param key welches Gesucht werden soll
     * 
     */
    private BinaryTreeNode<K, V> getNode(final K key) {
        BinaryTreeNode<K, V> current = this.root;
        while (current != null) {
            int compareKeyInt = key.compareTo(current.getKey());
            if (compareKeyInt == 0) {
                return current;
            } else if (compareKeyInt < 0) {
                current = current.getLeft();
            } else {
                current = current.getRight();
            }
        }
        return null;
    }
    
    
    /**
     * Helpermethode erwartet eine Instanz von Consumer<V>. Verarbeitung der Nutzdaten (Typ V) also item wird durch consumer.consume
     * realisiert
     */
    private void traverseDepthFirstPreOrderHelper(BinaryTreeNode<K, V> node, Consumer<V> consumer) {
        if (node == null) {
            return;
        }
        consumer.consume(node.getItem());
        traverseDepthFirstPreOrderHelper(node.getLeft(), consumer);
        traverseDepthFirstPreOrderHelper(node.getRight(), consumer);
    }

    /**
     * Methode traversiert Baum in PreOrder Reihenfolge
     * @return preorder traversierter Baum
     */
    public void traverseDepthFirstPreOrder(Consumer<V> consumer) {
        traverseDepthFirstPreOrderHelper(this.root, consumer);
    }
    
    
    public static void main(String[] args) {
    	final BinaryTree<Integer, String> tree = new BinaryTree<>();

    	tree.insertSorted(16, "(16)");
    	tree.insertSorted(8, "(8)");
    	tree.insertSorted(32, "(32)");
    	tree.insertSorted(4, "(4)");
    	tree.insertSorted(6, "(6)");
    	System.out.println(tree.isBalanced()); // returns false
    	
    	tree.insertSorted(12, "(12)");
    	tree.insertSorted(18, "(18)");
    	tree.insertSorted(48, "(48)");
    	tree.insertSorted(20, "(20)");
    	System.out.println(tree.isBalanced()); // returns true
    	
    	System.out.println(tree.height()); // returns 4
    	
    	System.out.println(tree.get(48)); // returns "(48)"
    	System.out.println(tree.get(120)); // return null
    	
    	
    	tree.insertSorted(48, "(48 new)");
    	
    	System.out.println(tree.get(48)); // returns "(48 new)"
    	
    	System.out.println();
        
    	// returns "(16)", "(8)", "(4)", "(6)", "(12)", "(32)", "(18)", "(20)", "(48 new)"
    	tree.traverseDepthFirstPreOrder((v) -> System.out.print(v));
    	
    	System.out.println();
    	
    	tree.removeSorted(16);
    	
    	System.out.println();
    	// returns "(18)", "(8)", "(4)", "(6)", "(12)", "(32)", "(20)", "(48 new)
    	tree.traverseDepthFirstPreOrder((v) -> System.out.print(v));

        
    }
    
}