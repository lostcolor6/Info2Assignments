package info2;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

/*
 * Wegen Spezialkonstruktor in Star, muss in allen Unterklassen super(x) als
 * allererste Anweisung bedient werden.
 */
public class Betelgeuse extends Star {
	public Betelgeuse() {
		super(10_000_000L);

	}
}
