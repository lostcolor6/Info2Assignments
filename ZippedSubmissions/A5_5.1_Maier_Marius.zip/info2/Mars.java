package info2;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

public class Mars extends Planet {

}
