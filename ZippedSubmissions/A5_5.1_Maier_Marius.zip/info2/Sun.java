package info2;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

/*
 * Wegen Spezialkonstruktor in Star, muss in allen Unterklassen super(x) als
 * allererste Anweisung bedient werden.
 */

public class Sun extends Star {
	public Sun() {
		super(12_000_000_000L);
	}
}
