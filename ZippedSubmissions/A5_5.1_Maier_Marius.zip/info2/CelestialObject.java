package info2;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

public class CelestialObject {

	private double mass;

	public void setMass(double mass) {
		if (mass > 0) {
			this.mass = mass;
		} else {

		}
	}

	public double getMass() {
		return this.mass;
	}

	public static void main(String[] args) {

	}

}
