package info2;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

public class Star extends CelestialObject {

	private long age;
	private long maxAge;

	public Star(long maxAge) {
		if (maxAge > 0) {
			this.maxAge = maxAge;
		}

		else {

		}
	}

	public long getAge() {
		return this.age;
	}

	public void setAge(long age) {
		if (age > 0) {
			this.age = age;
		} else {

		}
	}

	public long getMaxAge() {
		return this.maxAge;
	}

	/*
	 * Berechnet verbleibende Lebensdauer des Sternes
	 */
	public long estimateLifeTime() {
		if (this.maxAge >= this.age) {
			return maxAge - age;
		} else {
			return 0;
		}
	}
}
