package info2;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

public class Planet extends CelestialObject {

	private long degreeOfInfection;

	public long getDegreeOfInfection() {
		return this.degreeOfInfection;
	}

	/*
	 * Fügt dem Wert "degreeOfInfection" ein gegebenen Wert "degree" hinzu. Deckt
	 * den Fall ab, keine Negative Anzahl an Menschen auf einem Planeten/bzw.
	 * "degreeOfInfection" geht nicht ins Negative. Deckt gleichzeitig auch den Fall
	 * ab, wenn "degree" > max long-wert, da in diesem Fall der long-wert ins
	 * Negative konvertiert wird und der if-Fall zuschlägt.
	 */
	public void infectWithHumans(long degree) {
		if (this.degreeOfInfection + degree < 0) {
			this.degreeOfInfection = 0;
		} else {
			this.degreeOfInfection = this.degreeOfInfection + degree;
		}
	}

	/*
	 * Durch den Aufruf wird der Planet von der Infektion der Menschen "geheilt"
	 * bzw. "degreeOfInfection" wird auf 0 gesetzt.
	 */
	public void heal() {
		this.degreeOfInfection = 0;
	}
}
