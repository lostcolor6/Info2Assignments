package info2.ram;

import info2.ram.instruction.Exit;
import info2.ram.instruction.Instruction;
import info2.ram.instruction.Load;
import info2.ram.instruction.Print;
import info2.ram.instruction.dyadic.Add;
//import info2.ram.instruction.dyadic.Mul;
import info2.ram.instruction.jump.Jez;
//import info2.ram.instruction.jump.Jmp;
import info2.ram.instruction.monadic.Decr;

public class Fibunacci {
    
    public static void main(String[] args) {
        //
        // Create instance of Random Access Machine.
        //
        final Ram ram = new Ram();
        //
        // This program calculates the fibunacci number of n.
        //fib(1) = 1
        //fib(2) = 1
        //fib(n) = fib(n−1) + fib(n−2)
        //
        final long n = 8;
        //
        final Instruction[] program = {
            new Load(n, 0),   // 0: loads value of n into memory at address 0
            new Load(n, 1),   // 1: loads value n into memory at address 1
            new Jez(0, 7),    // 2: jumps to instruction 6 if the value at address 0 is 0 (loop head) 
            
           
            
            //n−1
            new Decr(0, 0),   // 3: decreases value in memory[0] by 1 and stores result in memory[0]
            
            //n−2
            new Decr(1, 1),   // 4: decreases value in memory[1] by 1 and stores result in memory[1]
            new Decr(1, 1),   // 5: decreases value in memory[1] by 1 and stores result in memory[1]
            
            
            //new Jmp(3),       //6  : jump to if-statements //fib(1) = 1 //fib(2) = 1 when calculation reached that point

            new Add(0, 1, 1), //7: Adds memory[0] and memory[1] and stores it in memory[1]
           
            new Print(1),     // 8: prints memory[1]
            new Exit()        // 9: terminates the program
        };
        //Aufgegeben °~°   Die in Memory 0 gespeicherten Werte von  n−1 und in Memory 1 n-2 müssen nochmal durch den Zyklus 
        //fib(n) = fib(n−1) + fib(n−2) gehen bis ein Endkriterium erreicht wird ( ich glaube fib(1) = 1 bzw. fib(2) = 1 ) 
        //aber keine Ahnung wie ich das implimentieren soll...
        
        //
        // Executes the program.
        // 
        ram.run(program);
    }
}