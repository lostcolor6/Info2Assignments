//Marius Maier 
//Matrikelnummer:6413594

package info2;

public class Series {
	// Exercise Task
	// 1.2 a)
	public static int sumUp(int n) {
		int result = 0;
		for (int i = 1; i <= n; i++) {
			result = result + i;
		}

		// TODO: check

		return result;
	}

	// Exercise Task
	// 1.2 b)
	public static void multiplicationTable(int n) {
		int result = 0;
		for (int i = 1; i <= 10; i++) {
			int k = i * n;
			System.out.println(n + " x " + i + " = " + k );
		}

		// TODO: check

	}

	// Exercise Task
	// 1.3 c)
	public static void fizzBuzz() {
		for(int i=1; i <= 100; i++) {
			if (i % 3 == 0 && i % 5 == 0) { //Vielfache von 3 und 5= FizzBuzz
				System.out.println("FizzBuzz");
				}
				else if(i % 5 == 0) { //Vielfache von 5 = Buzz
					System.out.println("Buzz");
					}
				else if (i % 3 == 0) { //Vielfache von 3 = Fizz
					System.out.println("Fizz");
					}
				else System.out.println(i);
					
			/*Anmerkung für mich: Steht der If-Fall von FizzBuzz ganz unten so wird z.b.: 
			 * nach Erfüllung von dem Fizz-Zweig nicht mehr weiter die Fälle gecheckt.		
			 */
					}
		// TODO: check
	}

	// Exercise Task
	// 1.4 d)
	public static void chessBoard(int n) {
		for (int j= 1; j<= n; j++) {
			if (j % 2 == 0) { // Wenn die Zeile gerade, dann: n Folge von 0 und 1 (wobei gerade Stellen 0 sind)
			

		for (int i= 1; i<= n; i++) {
			if (i % 2 == 0 && i==n) { //Bei der letzten Zahl der Zeile wird kein Leerzeichen angebracht.
			System.out.print("1");
			}
			else if (i % 2 != 0 && i==n) { //Bei der letzten Zahl der Zeile wird kein Leerzeichen angebracht.
				System.out.print("0");
			}
		    else 
		    {
		    	if (i % 2 == 0) {
		    		System.out.print("1 ");
		    	}
		    	else System.out.print("0 ");
		    }
		
				
		}	
	}
			
			else  // Ansonsten, wenn die Zeile ungerade, dann: n Folge von 0 und 1 (wobei gerade Stellen 1 sind)
				for (int i= 1; i<= n; i++) 
				{
				if (i % 2 == 0 && i==n) { //Bei der letzten Zahl der Zeile wird kein Leerzeichen angebracht.
					System.out.print("0");
					}
				else if (i % 2 != 0 && i==n) { //Bei der letzten Zahl der Zeile wird kein Leerzeichen angebracht.
					System.out.print("1");
				}
				    else 
				    	if (i % 2 == 0 ) {
				    		System.out.print("0 ");
				    	}
				    	else System.out.print("1 ");
				    	
				}
			System.out.println();
				
			// TODO: check
		
	}
			
	}
	

	// Exercise Task
	// 1.5 e)
	public static int factorial(int n) {
		int result = 1263545845;
		int k = 1;
		int fak = 1;
		
		if (n == 0) {
			System.out.println("0");
		}
		else {
		do {
			fak = fak * k;
			k++;
		} while (k <= n);
		//System.out.println(fak);
		// TODO: fill me
		}
		return fak;
	}

	// Exercise Task
	// 1.6 f)
	public static double e(int n) {
		double result = 0;
		double k = 1.0;
		double j = 1.0;
		if(n>0) { //für n>0 ansonsten nichts
		
		    for (int i = 1; i <= n; i++) {
		        j = j * i; // Nenner von den Teilelmenten
		        k = k + (1.0 / j); //Zähler und Aufaddieren der Teilelemente
		    }
		    //System.out.println(k);
		}		

		// TODO: check

		return k;
	}

	// Exercise Task
	// 1.7 g)
	public static void reverseDigits(int n) {
		for (int i = n; i > 0; i = i/ 10) {
	        int x = i % 10; // letzte Ziffer der Zahl entnehmen
	        System.out.println(x); 
	    }
		// TODO: check
	}

	// Exercise Task
	// 1.8 h)
	public static double leibnizSeries(int n) {
		double res = 0;
		
		for (int i = 0; i <= n; i++) {
			
			double k = Math.pow(-1, i)/(2*i+1);
			res = res + k;
			
		}
		
		//Fehlerhafter code/Notizen
		/*for (int i = 0; i < n; i++) {
	        double x;
	        if (j == 1) { // wenn j=1 ist positives Vorzeichen
	            x = 1.0 / (2 * i + 1);
	        } else { // ansonten negatives Vorzeichen
	            x = -1.0 / (2 * i + 1);
	        }
	        res = res + x;
	        if (j == 1) { //in der nächsten "Teilrechnung" wird das Vorzeichen wieder umgekehrt.
	            j = -1;
	        } else {
	            j = 1;
	        }
	    } */
		//System.out.println(4 * res);	

		// TODO: fill me

		return 4* res;
	}//2.8952380952380956
	 //2,895238095238095	

	public static void main(String[] args) {

		System.out.println("1.2 a) ");
		System.out.println(sumUp(10));

		System.out.println("1.2 b) ");
		multiplicationTable(4);

		System.out.println("1.3 c) ");
		fizzBuzz();

		System.out.println("1.4 d) ");
		chessBoard(4);

		System.out.println("1.5 e) ");
		System.out.println(factorial(3));

		System.out.println("1.6 f) ");
		System.out.println(e(3));

		System.out.println("1.7 g) ");
		reverseDigits(1239);

		System.out.println("1.8 h) ");
		System.out.println(leibnizSeries(3));

	}
}
