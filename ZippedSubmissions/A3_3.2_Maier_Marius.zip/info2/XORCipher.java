package info2;



//Namen:
//Viet Hoang Pham
//Marius Maier


public class XORCipher {
    
    //
    // This table contains 64 possible chars that are
    // used as alphabet for this encryption exercise.
    // We can use 6 bits (e.g. the most right 6 bits of an
    // int value) to uniquely encode a character.
    //
    public static char[] CHAR_TABLE = {
        ' ', '\n', ',', '.', '\'', '-', ':', ';', '?', '(', ')', '!',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
        'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
        'U', 'V', 'W', 'X', 'Y', 'Z', 
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
        'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
        'u', 'v', 'w', 'x', 'y', 'z'
    };
    
    // ----------------------------------------------------------------
    // Exercise 2 (a)
    // ----------------------------------------------------------------
    public static char valueToChar(int code) {
    	if(code < -1 && code > 64) { //Sonderfall außerhalb Bereich der Elemente von CHAR_TABLE
    		return CHAR_TABLE[0];
    	}
    	else {
    		return CHAR_TABLE[code];
    	}
    }
    // TODO: check
    
    
    // ----------------------------------------------------------------
    // Exercise 2 (b) 
    // ----------------------------------------------------------------
    public static int charToValue(char chr) {
    	int i_char = -1; // bei i++ sucht ab Stelle 0    Index vom Char	
    for ( int i = 0; i < CHAR_TABLE.length; i++) { 
    	if ( chr == CHAR_TABLE[i]) {
    	i_char = i;    
    }
  	
    }
    return i_char;
    }
    // TODO: check
    
    
    
    // ----------------------------------------------------------------
    // Exercise 2 (c)
    // ----------------------------------------------------------------
    public static int[] stringToValues(String str) {
    	int[] int_str = new int[str.length()];
    	
    if ( str == null) { //Sonderfall, aber warum dead code?
    	int[] int_nothing = {};
    	return int_nothing;
    }
    else {
    	for (int i = 0; i < str.length(); i++) {
    		
    		int_str[i]=charToValue(str.charAt(i)); 
    	}
    }
    	return int_str;
    }
   // }
    // TODO: check
    
    
    
    // ----------------------------------------------------------------
    // Exercise 2 (d)
    // ----------------------------------------------------------------
    public static String valuesToString(int[] codes) {
    	 if ( codes == null) {
    	    	String s = "";
    	    	return s;
    	    }
    	 else {
    		 char[] char_str = new char[codes.length]; //neues array der Länge vom int array 
    		
    		 for (int i = 0; i < codes.length; i++) {
    		 char_str[i] =  valueToChar(codes[i]);
    		
    		 
    	 }
    		 String x = new String(char_str); // konvertierung von chars zu einem einzigen String
    		return x;
    	 }
    	
    	
    }
    // TODO: check
    
    
    
    // ----------------------------------------------------------------
    // Exercise 2 (e)
    // ----------------------------------------------------------------
    public static int[] encryptDecrypt(int[] msg, int[] key) {
    	if ( msg == null || key == null) {
	    	return msg;
	    }
    
    else {
    	int[] x = new int[msg.length]; //neues array der länge von msg string
        int length_key = key.length;
        
        for (int i = 0; i < msg.length; i++) {
            int msg_x = msg[i]; //jedes ite Element von msg array
            int key_y = key[i % length_key]; //jedes ite Element von key array/ zyklisches fortsetzen  mit modulo
            int encryptedValue = msg_x ^ key_y; //xor encryptung
            
            x[i] = encryptedValue;
        }
        
        return x;
    	
    }
    }
    // TODO: check


    
    // ----------------------------------------------------------------
    // Exercise 2 (f)
    // ----------------------------------------------------------------
    public static String encryptDecrypt(String msg, String key) {
    	if (msg == null || key == null) { //Sonderfall 
    		return "keine gültige Eingabe";
    	}
    	
    	/*Müsste man hier nochmal den Sonderfall abdecken, falls der String aus nichts als Leerzeichen besteht ?
    	-> "nichts zum en-/decrypten"
    	ggf. mit einem for loop über die einzelnen Indexstellen vom String iterieren und checken ob == " ", oder 
    	kann man davon ausgehen, dass in diesem Fall valide Eingaben zu erwarten sind?*/
    
    	else {
    	int[] msg_int = stringToValues(msg); // I.)
    	int[] key_int = stringToValues(key); // I.)
    	int[] crypt_int = encryptDecrypt(msg_int, key_int); // II.)
    	String msg1 = valuesToString(crypt_int); // III.)
    	return msg1;
    	}
    	
    	
    	
    }
    // TODO: check
        
    // ich weiß leider nicht wie ich die Fehlermeldung "[javac] Warning: src/info2/XORCipher.java modified in the future." bei Infomark behebe :(
    // Meine Ordnerstruktur ist eig: A3_3.2_Viet-Hoang_Pham_Maier_Marius.zip/JRE System Library [jdk-20]
    //                                                                      /src/info2/ArrayTools.java
    //                                                                                /XORCipher.java
    // ----------------------------------------------------------------
    
    public static void main(String[] args) {
        final String msg = "Dieser Text ist sehr geheim...";
        final String key = "keyword";
        
         final String cipher = encryptDecrypt(msg, key);
         final String decrypted = encryptDecrypt(cipher, key);
        
        //
        // Wenn alles richtig implementiert wurde, sollte
        // der String decrypted wieder genau dem String 
        // msg entsprechen, waehrend der String cipher fuer
        // uns nicht lesbar ist.
        //
        
         System.out.println(msg);
         System.out.println(cipher);
         System.out.println(decrypted);
        
        System.out.println();
        
        
        //EIGNE TESTS
       /* System.out.println(valueToChar(63));
        System.out.println(valueToChar(0));
        System.out.println(charToValue('z'));
        System.out.println(charToValue(' '));
        System.out.println();
        System.out.println(valuesToString(new int[]{12, 0, 13, 0, 14, 0, 15}));
        System.out.println(ArrayTools.asString(stringToValues("A B C D")));
        System.out.println();*/
        
       
        
       
    }
}