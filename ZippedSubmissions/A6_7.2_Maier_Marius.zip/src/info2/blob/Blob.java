/*
 * OFFIZIELE 
 * Viet-Hoang Pham
 * Marius Maier
 * 
 */

package info2.blob;

public class Blob {
    
    public static final int CELL_STATE_FREE = Maze.DEFAULT_CELL_STATE;
    public static final int CELL_STATE_BLOB_FRESH = CELL_STATE_FREE + 1;
    public static final int CELL_STATE_BLOB_DEAD = CELL_STATE_FREE + 2; 
    
    /**
     * Methode "infest" erzeugt durch Rekursion die Suche des "Blobs" im "Maze".
     *
     * @param maze Ein gegebens Labyrinth 
     * @param x    X-Koordinate im Labyrinth.
     * @param y    Y-Koordinate im Labyrinth.
     * @return true falls das Ziel ("Essen") erreicht wurde, ansonsten false.
     */
    
	public boolean infest(final Maze maze, final int x, final int y) {

		maze.setCellState(x, y, CELL_STATE_BLOB_FRESH);

		// Abbruchfall der Rekursion/ falls Ziel erreicht wurde.
		if (maze.isGoal(x, y)) {
			return true;

		} else {

			/*
			 * Zu erfragen: 1. Gibt es links/rechts/oben/unten vom Blob eine Mauer? 2. Wurde
			 * die Zelle/Feld schon besucht?
			 * 
			 * wenn ja: Rekursion auf die neue Zelle/Feld
			 * 
			 * --> Geht alle möglichen Richtungen ab, wenn keins der If-Fälle zutrifft:
			 * Sackgasse/ Blob absterben lassen
			 */

			if (!maze.isWallLeft(x, y) && maze.getCellState(x - 1, y) == Maze.DEFAULT_CELL_STATE) {
				if (infest(maze, x - 1, y)) {
					return true;
				}
			}

			if (!maze.isWallRight(x, y) && maze.getCellState(x + 1, y) == Maze.DEFAULT_CELL_STATE) {
				if (infest(maze, x + 1, y)) {
					return true;
				}
			}

			if (!maze.isWallAbove(x, y) && maze.getCellState(x, y - 1) == Maze.DEFAULT_CELL_STATE) {
				if (infest(maze, x, y - 1)) {
					return true;
				}
			}

			if (!maze.isWallBelow(x, y) && maze.getCellState(x, y + 1) == Maze.DEFAULT_CELL_STATE) {
				if (infest(maze, x, y + 1)) {
					return true;
				}
			}

			maze.setCellState(x, y, CELL_STATE_BLOB_DEAD);
			return false;
		}
	}
}
      
    
     
    
    	 
    
    	 
     
     
    
    
    
