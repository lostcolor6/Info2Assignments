package info2.blob.gui;

import info2.blob.Maze;

public interface MazeListener {
    public void onUpdate(final Maze maze);
}