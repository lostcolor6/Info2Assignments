/*
 * OFFIZIELE 
 * Viet-Hoang Pham
 * Marius Maier
 * 
 */

package info2.recursion;

//import java.util.Random;

public class RecursiveMath {

	public static int incr(int a) {
		return a + 1;
	}

	public static int decr(int a) {
		return a - 1;
	}

	// ----------------------------------------------------------------
	// Exercise 7.1 a
	// ----------------------------------------------------------------
	/**
	 * Methode "add" addiert zwei ints zusammen. b = 0 ist der Abbruchfall und
	 * gleichzeitig auch der Fall falls a und b = 0 sind wenn b > 0 ist, wird a so
	 * oft um 1 hochgezählt wie b runtergezählt wird. wenn b < 0 ist, wird b so oft
	 * um 1 hochgezählt wie a runtergezählt wird.
	 * 
	 * @param a
	 * @param b
	 * @return a + b
	 */

	public static int add(int a, int b) {
		if (b == 0) {
			return a;
		} else if (a == 0) {
			return b;
		}

		else if (b > 0) {

			return add(incr(a), decr(b));
		} else

		{
			return add(decr(a), incr(b));
		}
	}

	// ----------------------------------------------------------------
	// Exercise 7.1 b
	// ----------------------------------------------------------------
	/**
	 * Methode "sub" subtrahiert zwei ints. b = 0 ist der Abbruchfall und
	 * gleichzeitig auch der Fall falls a und b = 0 sind wenn b > 0 ist, wird a so
	 * oft um 1 runtergezählt wie b runtergezählt wird. wenn b < 0 ist, wird a so
	 * oft um 1 hochgezählt wie b hochgezählt wird.
	 * 
	 * @param a
	 * @param b
	 * @return a - b
	 */

	public static int sub(int a, int b) {
		if (b == 0) {
			return a;
		} else if (b > 0) {
			return sub(decr(a), decr(b));
		} else {
			return sub(incr(a), incr(b));
		}
	}

	// ----------------------------------------------------------------
	// Exercise 7.1 c
	// ----------------------------------------------------------------
	/**
	 * Methode "mul" multipliziert zwei ints. b = 0 ist der Abbruchfall und
	 * gleichzeitig auch der Fall falls a und b = 0 sind wenn b > 0 ist, wird a, b
	 * mal auf sich selber addiert. wenn b < 0 ist, wird -a, b mal
	 * 
	 * @param a
	 * @param b
	 * @return a * b
	 */
	public static int mul(int a, int b) {
		if (b == 0) {
			return 0;
		} else if (b > 0) {
			return add(a, mul(a, decr(b)));
		} else {
			return add(sub(0, a), +mul(a, incr(b)));

		}
	}

	/*
	 * public static int mul(int a, int b) { if(b == 0) { return 0; } else if (b ==
	 * 0){ return 0; } else if (b > 0) {
	 * 
	 * return add(a, mul(a, decr(b))); } else if(b < 0){ return sub(0, mul(a,
	 * incr(b))); } else if (a > 0) {
	 * 
	 * return add(b, mul(b, decr(a))); } else { return sub(0, mul(b, incr(a))); } }
	 */

	// ----------------------------------------------------------------
	// Exercise 7.1 d
	// ----------------------------------------------------------------

	/**
	 * Methode "div" dividiert zwei ints. a = 0 ist der Abbruchfall. a = 0 ist der
	 * unerlaubte Fall (Division durch 0) wenn a und b negativ sind wird der Betrag
	 * genommen und positivDiv angewand wenn a und b positiv sind wird positivDiv
	 * angewand
	 * 
	 * 
	 * @param a
	 * @param b
	 * @return a / b
	 */

	public static int div(int a, int b) {
		if (a == 0) {
			if (b == 0) {
				return 0;
			} else
				return 0;

		} else if (b == 0) {
			System.out.println("Fehler: Nicht durch 0 teilen");
			return 0;
		} else if (a < 0) {
			if (b < 0) {
				return positiveDiv(abs(a), abs(b));
			} else
				return sub(0, positiveDiv(abs(a), abs(b)));
		} else if (a > 0) {
			if (b > 0) {
				return positiveDiv(a, b);
			} else
				return sub(0, positiveDiv(abs(a), abs(b)));
		} else {
			return sub(0, positiveDiv(abs(a), abs(b)));
		}
	}

	/**
	 * Helfermethode für "div" welche die Division für positive Zahlen durchführt
	 * 
	 * @param a
	 * @param b
	 * @return a/b (positive ints)
	 */
	public static int positiveDiv(int a, int b) {
		if (a < b) {
			return 0;
		} else {
			return incr(positiveDiv(sub(a, b), b));

		}
	}

	/**
	 * Helfermethode für "div" die den Betrag eines ints returnt
	 * 
	 * @param a
	 * @return absolute of a
	 */
	public static int abs(int a) {
		if (a < 0) {
			return sub(0, a);
		} else if (a > 0) {
			return a;
		} else {
			return a;
		}
	}

	public static void main(String[] args) {
		
		// TestAdd();
		// TestSub();
		// TestMul();
		// TestDiv();
		
		
		
		// Test für "abs"
		System.out.println("Test abs:");
		System.out.println(abs(-2) == Math.abs(-2));
		System.out.println(abs(2) == Math.abs(2));

		// TEST-WERTE für add
		System.out.println("Test add:");
		System.out.println(add(2, 2) == 2 + 2);
		System.out.println(add(2, 4) == 2 + 4);
		System.out.println(add(4, 2) == 4 + 2);
		System.out.println(add(-2, 2) == -2 + 2);
		System.out.println(add(2, -2) == 2 + -2);
		System.out.println(add(0, 0) == 0 + 0);
		System.out.println(add(0, 2) == 0 + 2);
		System.out.println(add(2, 0) == 2 + 0);
		System.out.println(add(0, -2) == 0 + -2);
		System.out.println(add(-2, 0) == -2 + 0);

		// TEST-WERTE für sub
		System.out.println("Test sub:");
		System.out.println(sub(2, 2) == 2 - 2);
		System.out.println(sub(2, 4) == 2 - 4);
		System.out.println(sub(4, 2) == 4 - 2);
		System.out.println(sub(-2, 2) == -2 - 2);
		System.out.println(sub(2, -2) == 2 - (-2));
		System.out.println(sub(0, 0) == 0 - 0);
		System.out.println(sub(0, 2) == 0 - 2);
		System.out.println(sub(2, 0) == 2 - 0);
		System.out.println(sub(0, -2) == 0 - (-2));
		System.out.println(sub(-2, 0) == -2 - 0);

		// TEST-WERTE für mul
		System.out.println("Test mul:");
		System.out.println(mul(2, 2) == 2 * 2);
		System.out.println(mul(2, 4) == 2 * 4);
		System.out.println(mul(4, 2) == 4 * 2);
		System.out.println(mul(-2, 2) == -2 * 2);
		System.out.println(mul(2, -2) == 2 * (-2));
		System.out.println(mul(0, 0) == 0 * 0);
		System.out.println(mul(0, 2) == 0 * 2);
		System.out.println(mul(2, 0) == 2 * 0);
		System.out.println(mul(0, -2) == 0 * (-2));
		System.out.println(mul(-2, 0) == -2 * 0);

		// TEST-WERTE für div
		System.out.println("Test div:");
		System.out.println(div(2, 2) == 2 / 2);
		System.out.println(div(2, 4) == 2 / 4);
		System.out.println(div(4, 2) == 4 / 2);
		System.out.println(div(-2, 2) == -2 / 2);
		System.out.println(div(2, -2) == 2 / (-2));
		System.out.println(div(0, 2) == 0 / 2);
		System.out.println(div(0, -2) == 0 / (-2));
		


	}

	/*
	 * 
	 * Tests für eingebaute rekursive Methoden. 
	 * Generiert zufällige Zahlen von -100 bis 100 und
	 * speichert sie in x/y. Testet 1000 mal ob die rekusrive Methode auch so
	 * funktioniert wie die eingebaute Funktion in Java. Java Random Libary wird dafür gebraucht.
	 * 
	 */
	
	/*
	
	 
	public static void TestAdd() {
		// Random Nummer von -100 bis 100
		Random random = new Random();
		int a_plus;
		for (int i = 0; i < 1000; i++) {

			int x = (int) random.nextInt(201) - 100;
			int y = (int) random.nextInt(201) - 100;
			a_plus = x + y;
			if (add(x, y) == x + y) {
				System.out.print(x + " + " + y + " = " + a_plus + " " + add(x, y) + " gleich");
				System.out.println();
			} else {
				System.out.print(x + " + " + y + " = " + a_plus + " " + add(x, y) + " nicht gleich");
				System.out.println();

			}

		}
	}


	
	public static void TestSub() {
		// Random Nummer von -100 bis 100
		Random random = new Random();
		int a_minus;
		for (int i = 0; i < 1000; i++) {

			int x = (int) random.nextInt(201) - 100;
			int y = (int) random.nextInt(201) - 100;
			a_minus = x - y;
			if (sub(x, y) == x - y) {

				System.out.print(x + " - " + y + " = " + a_minus + " " + sub(x, y) + " gleich");
				System.out.println();
			} else {
				System.out.print(x + " - " + y + " = " + a_minus + " " + sub(x, y) + " nicht gleich");
				System.out.println();
			}

		}
	}

	public static void TestMul() {
		// Random Nummer von -100 bis 100
		Random random = new Random();
		int a_mul;
		for (int i = 0; i < 1000; i++) {
			int x = (int) random.nextInt(201) - 100;
			int y = (int) random.nextInt(201) - 100;
			a_mul = x * y;
			if (mul(x, y) == x * y) {

				System.out.print(x + " * " + y + " = " + a_mul + " " + mul(x, y) + " gleich");
				System.out.println();
			} else {
				System.out.print(x + " * " + y + " = " + a_mul + " " + mul(x, y) + " nicht gleich");
				System.out.println();
			}

		}
	}

	public static void TestDiv() {
		// Random Nummer von -100 bis 100
		Random random = new Random();
		int a_div;
		int y;
		for (int i = 0; i < 1000; i++) {
			int x = (int) random.nextInt(201) - 100;
			// Generiert für y alles zwischen -100 und 100 aber ohne die 0
			do {
				y = random.nextInt(201) - 100;
			} while (y == 0);

			a_div = x / y;
			if (div(x, y) == x / y) {

				System.out.print(x + " / " + y + " = " + a_div + " " + div(x, y) + " gleich");
				System.out.println();
			} else {
				System.out.print(x + " / " + y + " = " + a_div + " " + div(x, y) + " nicht gleich");
				System.out.println();
			}

		}
	}
*/
}
