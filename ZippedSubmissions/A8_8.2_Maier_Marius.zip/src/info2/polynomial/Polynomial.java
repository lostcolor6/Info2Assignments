/*
 * OFFZIELLE VERSION
 * Viet-Hoang Pham
 * Maier Marius
 * 
 */

package info2.polynomial;

import info2.polynomial.tools.PolynomialParser;

/**
 * A simple list implementation representing polynomials a recursive structures
 * (linked list).
 * 
 * @author Sebastian Otte
 */
public class Polynomial {

	private Monomial head;
	private Polynomial next;

	/**
	 * Return this head value of the list.
	 * 
	 * @return Head value as Monomial.
	 */
	public Monomial getHead() {
		return this.head;
	}

	/**
	 * Returns the remaining list.
	 * 
	 * @return Remaining polynomial.
	 */
	public Polynomial getNext() {
		return this.next;
	}

	/**
	 * Initializes a polynomial with just one Monomial. The remaining list null.
	 * 
	 * @param head Instance of Monomial.
	 */
	public Polynomial(final Monomial head) {
		this(head, null);
	}

	/**
	 * Initializes a polynomial with with a given monomial and another poylnomial
	 * (as remaining list).
	 * 
	 * @param head Instance of Monomial.
	 * @param next Instance of Polynomial.
	 */
	public Polynomial(final Monomial head, final Polynomial next) {
		this.head = head;
		this.next = next;
	}

	/**
	 * Returns true if the current polynomial node has a next polynomial node.
	 */
	public boolean hasNext() {
		return this.next != null;
	}

	/**
	 * Returns the degree of the polynomial, which is the highest degree value of
	 * all contained monomials.
	 * 
	 * @return Degree of the polynomial.
	 */
	public int degree() {
		if (!this.hasNext()) {
			return this.head.degree;
		}
		return Math.max(this.head.degree, this.next.degree());
	}

	/**
	 * Creates a copy of the polynomial recursively.
	 * 
	 * @return New polynomial list.
	 */
	public Polynomial copy() {
		if (!this.hasNext()) {
			return new Polynomial(this.head);
		}
		return new Polynomial(this.head, this.next.copy());
	}

	/**
	 * Negates the polynomial, which effectively toogles the signs of the
	 * coefficients of all contained monomials.
	 * 
	 * @return New polynomial list.
	 */
	public Polynomial negate() {
		if (!this.hasNext()) {
			return new Polynomial(this.head.negate());
		} else {
			return new Polynomial(this.head.negate(), this.next.negate());
		}
	}

	/**
	 * Appends all monomials of the given polynomial list (other) at the end of this
	 * polynomial. This is a plain list append operation.
	 * 
	 * @param Another polynomial.
	 * @return New polynomial list.
	 */
	public Polynomial append(final Polynomial other) {
		if (other == null) {
			return this;
			//
			// Alternative:
			//
			// return this.copy();
		} else if (!this.hasNext()) {
			return new Polynomial(this.head, other.copy());
			//
			// Alternative:
			//
			// this.next = other.copy();
			// return this;
		} else {
			return new Polynomial(this.head, this.next.append(other.copy()));
			//
			// Alternative;
			//
			// this.next = this.next.append(other);
			// return this;
		}
	}

	private Polynomial dropZerosCore() {
		if (this.head.coefficient.getNumerator() == 0) {
			if (!this.hasNext()) {
				return null;
			} else {
				return this.next.dropZerosCore();
			}
		} else {
			if (!this.hasNext()) {
				return new Polynomial(this.head);
				//
				// Alternative:
				//
				// return this;
			} else {
				return new Polynomial(this.head, this.next.dropZerosCore());
				//
				// Alternative:
				//
				// this.next = this.next.dropZerosCore();
				// return this;
			}
		}
	}

	/**
	 * This methods removes all monomials from the polynomial which have a zero
	 * coefficient.
	 * 
	 * @return New polynomial list.
	 */
	public Polynomial dropZeros() {
		final Polynomial result = this.dropZerosCore();
		if (result == null) {
			return new Polynomial(new Monomial(0, 0));
		}
		return result;
	}

	@Override
	public String toString() {
		if (!this.hasNext()) {
			return this.head.toString();
		} else {
			return this.head.toString() + " + " + this.next.toString();
		}
	}

	private boolean equalsHelper(final Polynomial other) {
		if (other == null) {
			return false;
		} else if (this.hasNext() != other.hasNext()) {
			return false;
		} else if (!this.hasNext()) {
			return this.head.equals(other.head);
		} else {
			return this.head.equals(other.head) && this.next.equalsHelper(other.next);
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Polynomial) {
			return equalsHelper((Polynomial) obj);
		}
		return false;
	}

	// ----------------------------------------------------------------
	// Exercise 2 (a)
	// ----------------------------------------------------------------
	/**
	 * Checkt ob das Polynom geordnet ist ( grad von links nach rechts absteigend )
	 * wenn Polynom nur ein Monom hat ist es automatisch sortiert. es wird das
	 * jetzige "tempDegree" mit dem nächsten verglichen mittels der while Schleife
	 * wird so lange über das Polynom iterriert bis null erreicht wurde d.h. das
	 * Ende des Polynoms
	 * 
	 * @return boolean, ob ein Polynom sortiert ist.
	 */
	public boolean isSorted() {
		if (!this.hasNext()) {
			return true;
		} else {
			int tempDegree = this.head.degree;

			while (this.next != null) {
				if (this.next.head.degree > tempDegree) {
					return false;
				}

				tempDegree = this.next.head.degree;
				this.next = this.next.next;
			}

			return true;
		}
	}

	// ----------------------------------------------------------------
	// Exercise 2 (b)
	// ----------------------------------------------------------------
	/**
	 * Fügt Monom vor dem Monom vom höchsten oder gleichen Grad im Polynom ein
	 * 
	 * @param m Monom das eingefügt werden soll
	 * @return ein Polynom mit eingefügtem Monom
	 */
	public Polynomial insertSorted(final Monomial m) {
		// falls erstes Monom Grad <= als m ist -> neues Polynom mit m ganz vorne und
		// rest Polynom
		if (m.degree >= this.head.degree) {
			return new Polynomial(m, this.copy());
		} else {
			// Abbruchfall
			if (!this.hasNext()) {
				return new Polynomial(this.head, new Polynomial(m));
				// Rekursion über Restpolynom
			} else {
				return new Polynomial(this.head, this.next.insertSorted(m));
			}
		}
	}

	// ----------------------------------------------------------------
	// Exercise 2 (c)
	// ----------------------------------------------------------------
 /**
  * Methode sortiert ein Polynom
  * @return sortiertes Polynom
  */
	public Polynomial sort() {
		// Nur ein Monom -> ist automatisch sortiert
		if (!hasNext()) {
			return this;
		}

		// Rekursion über Restpolynom
		Polynomial sortierteList = getNext().sort();

		// Fügt erstes Monom mittels insertSorted ein
		return sortierteList.insertSorted(this.getHead());
	}

	// ----------------------------------------------------------------
	// Exercise 2 (d)
	// ----------------------------------------------------------------
	/**
	 * Methode vereinfacht Polynom Bei der Vereinfachung eines Polynoms werden die
	 * Koeffizienten aller Monome mit demselben Exponenten addiert. Polynom ist
	 * anschließden sortiert.
	 * 
	 * @return vereinfachtes und sortiertes Polynom
	 */

	public Polynomial simplify() {
		// sortiert das angewandte Polynom
		Polynomial sortedPolynomial = sort();
		// Grundzuweisung des zu bearbeitenden Polynoms auf null
		Polynomial simplified = null;

//while Schleife iteriert über Monome vom sortierten Polynom
		while (sortedPolynomial != null) {
			// Grad des ersten Monoms
			int degree = sortedPolynomial.head.degree;
			Rational coefficient = sortedPolynomial.head.coefficient;
			boolean degreeVorhanden = false;

			// Deklaration von Variabeln für Iteration über Polynome
			Polynomial simplifiedJetziges = simplified;
			Polynomial davor = null;

			// while Schleife iteriert über Monome vom sortierten Polynom
			while (simplifiedJetziges != null) {
				// Kuckt ob der Grad schon im Polynom existiert
				if (simplifiedJetziges.head.degree == degree) {
					// Koeffizient erneuert indem er zum Monom addiert wird
					coefficient = coefficient.add(simplifiedJetziges.head.coefficient);
					degreeVorhanden = true;
					break;
				}
				// Geht zum nächsten Monom im Polynom
				davor = simplifiedJetziges;
				simplifiedJetziges = simplifiedJetziges.next;
			}

// Wenn es den Grad nicht gibt -> neues Monom wird erstellt
			if (!degreeVorhanden) {
				Monomial monomial = new Monomial(coefficient, degree);
				// Wenn das Polynom null ist wird das Monom zum neuen Polynom
				if (simplified == null) {
					simplified = new Polynomial(monomial);

				} else {
					// Ansonsten wird das Monom am Ende hinzugefügt
					davor.next = new Polynomial(monomial);
				}
			} else {
				// Wenn es den Grad gibt -> Koeffizient wird beim Monom erneuert
				Monomial updatedMonomial = new Monomial(coefficient, degree);
				simplifiedJetziges.head = updatedMonomial;
			}
			// Geht zum nächsten Monom im sortierten Polynom
			sortedPolynomial = sortedPolynomial.next;
		}

		return simplified;
	}
	// ----------------------------------------------------------------
	// Exercise 2 (e)
	// ----------------------------------------------------------------

	public Polynomial sub(final Polynomial other) {
		return this.add(other.negate());
	}

	/**
	 * Methode addiert zwei Polynome.
	 * Zwei Polynome werden addiert, indem die Koeffizienten der
     * Monome mit gleichem Exponenten beider Polynome addiert werden.
	 * @param other Additionspartner für Polynom
	 * @return Addiertes Polynom
	 */
	public Polynomial add(final Polynomial other) {
		// Kopie damit das Original Polynom nicht verändert wird
		Polynomial copiedPolynom = this.copy();

		// das zu addierende Polynom
		Polynomial addPolynom = other;
		// Iterriert über das übergebende Polynom
		while (addPolynom != null) {
			// jedes Monom wird in das kopierte Polynom eingefügt
			copiedPolynom = copiedPolynom.insertSorted(addPolynom.head);
			addPolynom = addPolynom.next;
		}

		return copiedPolynom.simplify();
	}

	// ----------------------------------------------------------------
	// Exercise 2 (f)
	// ----------------------------------------------------------------

	/**
	 * Methode multipliziert zwei Polynome
	 * Zwei Polynome werden multipliziert, indem
     * die Monome beider Polynome paarweise miteinander multipliziert werden. Zwei Monome werden
     * wiederum miteinander multipliziert, indem ihre Koeffizienten multipliziert und ihre Exponenten addiert werden.
     * 
	 * @param other Multiplikationspartner für Polynom
	 * @return multipliziertes Polynom
	 */
	public Polynomial mul(final Polynomial other) {
		// Ergebnis Polynom erstellt
		Polynomial Ergebnis = null;
		// Aktuelles Polynom erstellt
		Polynomial jetzigesThis = this;
		// Schleife über das aktuelle Polynom (this)
		while (jetzigesThis != null) {
			Polynomial jetzigesOther = other;
			// Schleife über das aktuelle andere Polynom
			while (jetzigesOther != null) {
				// Monome werden hier multipliziert
				Monomial multipliedMonom = jetzigesThis.head.mul(jetzigesOther.head);
				// multipliziertes Polynom erstellt
				Polynomial multipliedPolynom = new Polynomial(multipliedMonom);

				if (Ergebnis == null) {
					Ergebnis = multipliedPolynom;
				} else {
					// fügt das multiplizierte Polynom zum Ergebnis Polynom hinzu
					Ergebnis = Ergebnis.add(multipliedPolynom);
				}
				// wechselt zum nächsten Monom im anderen Polynom
				jetzigesOther = jetzigesOther.next;
			}
			// wechselt zum nächsten Monom im aktuellen Polynom
			jetzigesThis = jetzigesThis.next;
		}

		return Ergebnis.simplify();
	}

	// ----------------------------------------------------------------
	// Exercise 3
	// ----------------------------------------------------------------

	/*
	 * public Polynomial[] div(final Polynomial other) { // // TODO: Implement me.
	 * // return null; }
	 */
	public static void main(String[] args) {
		Polynomial p = PolynomialParser.parse("5x^2 + 1");
		Polynomial q = PolynomialParser.parse("4x^5 + 2x^4 +  1x^3 + 1/2x^2 + 1/4x^1 + 1/8x^0");

		// Einer meiner Mul-tests
		Polynomial p1 = PolynomialParser.parse("x^3 + 4x + 1");
		Polynomial p2 = PolynomialParser.parse("x + 3");
		Polynomial expectedResult = PolynomialParser.parse("x^4 + 3x^3 + 4x^2 + 13x + 3");
		Polynomial actualResult = p1.mul(p2);
		System.out.println(expectedResult);
		System.out.println(actualResult);

		System.out.println(p);
		System.out.println(q);

		System.out.println();

		System.out.println(PolynomialParser.parse("1"));
		System.out.println(PolynomialParser.parse("x"));
		System.out.println(PolynomialParser.parse("x^2 - x"));
		System.out.println(PolynomialParser.parse("5x^2 + 1"));

	}

}