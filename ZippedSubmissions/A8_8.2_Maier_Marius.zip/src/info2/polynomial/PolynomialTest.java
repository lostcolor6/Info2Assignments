package info2.polynomial;

import org.junit.Assert;
import org.junit.Test;

import info2.polynomial.tools.PolynomialParser;

public class PolynomialTest {
    
    private static Polynomial cons(final int ...degrees) {
        if (degrees.length == 0) return null;
        
        Polynomial p = null;
        
        for (int i = (degrees.length - 1); i >= 0; i--) {
            p = new Polynomial(new Monomial(1, degrees[i]), p);
        }
        
        return p;
    }
    
    private static Monomial m(final int degree) {
        //
        // coefficients are not relevant here.
        //
        return new Monomial(1, degree);
    }
    
    private static Monomial m(final int coefficient, final int degree) {
        return new Monomial(coefficient, degree);
    }
    
    private static Polynomial cons(final Monomial ...monomials) {
        if (monomials.length == 0) return null;
        
        Polynomial p = null;
        
        for (int i = (monomials.length - 1); i >= 0; i--) {
            p = new Polynomial(monomials[i], p);
        }
        
        return p;
    }
    
    @Test
    public void testDropZeros() {
        Assert.assertTrue(cons(m(0, 10)).dropZeros().equals(cons(m(0,0))));
        Assert.assertTrue(cons(m(1, 1)).dropZeros().equals(cons(m(1,1))));
        Assert.assertTrue(cons(m(1, 1), m(0, 2)).dropZeros().equals(cons(m(1,1))));
        Assert.assertTrue(cons(m(0, 3), m(0, 0), m(1, 1), m(0, 2)).dropZeros().equals(cons(m(1,1))));
    }

    
    @Test
    public void testAppend() {
        Assert.assertTrue(cons(1).append(cons(2)).equals(cons(1, 2)));
        Assert.assertTrue(cons(1).append(null).equals(cons(1)));
        Assert.assertTrue(cons(1, 2).append(cons(2)).equals(cons(1, 2, 2)));
        Assert.assertTrue(cons(1, 2, 3).append(cons(4, 5, 6)).equals(cons(1, 2, 3, 4, 5, 6)));
    }

    @Test
    public void testIsSorted() {
        Assert.assertTrue(cons(1).isSorted());
        Assert.assertTrue(cons(2,1).isSorted());
        Assert.assertTrue(cons(2,2).isSorted());
        Assert.assertTrue(cons(3,2,1).isSorted());
        Assert.assertTrue(cons(4,3,2,1).isSorted());
        Assert.assertTrue(cons(4,3,3,1).isSorted());

        Assert.assertFalse(cons(1,2).isSorted());
        Assert.assertFalse(cons(1,2,3).isSorted());
        Assert.assertFalse(cons(4,3,1,2).isSorted());
    }

    @Test
    public void testInsertSorted() {
        Assert.assertTrue(cons(1).insertSorted(m(2)).equals(cons(2,1)));
        Assert.assertTrue(cons(3,1).insertSorted(m(2)).equals(cons(3,2,1)));
        Assert.assertTrue(cons(3,2).insertSorted(m(1)).equals(cons(3,2,1)));
        Assert.assertTrue(cons(3,1).insertSorted(m(8)).equals(cons(8,3,1)));
        Assert.assertTrue(cons(3,2,1).insertSorted(m(2)).equals(cons(3,2,2,1)));
        Assert.assertTrue(cons(4,4,3,3,2,2).insertSorted(m(2)).equals(cons(4,4,3,3,2,2,2)));
        Assert.assertTrue(cons(4,4,3,3,2,2).insertSorted(m(0)).equals(cons(4,4,3,3,2,2,0)));
        Assert.assertTrue(cons(4,4,3,3,2,2).insertSorted(m(3)).equals(cons(4,4,3,3,3,2,2)));
        Assert.assertTrue(cons(4,4,3,3,2,2).insertSorted(m(4)).equals(cons(4,4,4,3,3,2,2)));
        Assert.assertTrue(cons(4,4,3,3,2,2).insertSorted(m(8)).equals(cons(8,4,4,3,3,2,2)));
    }

    @Test
    public void testSort() {
        Assert.assertTrue(cons(1).sort().equals(cons(1)));
        Assert.assertTrue(cons(1,1).sort().equals(cons(1,1)));
        Assert.assertTrue(cons(1,1,2).sort().equals(cons(2,1,1)));
        Assert.assertTrue(cons(1,2,3,4).sort().equals(cons(4,3,2,1)));
        Assert.assertTrue(cons(2,1,2,5,3,0,8,4).sort().equals(cons(8,5,4,3,2,2,1,0)));
    }
    
    @Test
    public void testSimplify() {
        Assert.assertTrue(cons(m(1,1)).simplify().equals(cons(m(1,1))));
        Assert.assertTrue(cons(m(1,1), m(1,1)).simplify().equals(cons(m(2,1))));
        Assert.assertTrue(cons(m(1,1), m(1,1), m(1,1)).simplify().equals(cons(m(3,1))));
        Assert.assertTrue(cons(m(1,1), m(1,3), m(1,1), m(1,3), m(1,1)).simplify().equals(cons(m(2,3), m(3,1))));
        Assert.assertTrue(cons(m(1,1), m(1,3), m(1,1), m(1,3), m(1,1)).simplify().equals(cons(m(2,3), m(3,1))));
        Assert.assertTrue(
            cons(m(1,1), m(1,7), m(1,3), m(1,1), m(1,3), m(1,1), m(1,3), m(1,3), m(1, 8)).simplify().equals(
                cons(m(1,8), m(1,7), m(4,3), m(3,1))
            )
        );
    }
    
    private static Polynomial poly(final String str) {
        return PolynomialParser.parse(str);
    }
    
    @Test
    public void testAdd() {
        Assert.assertTrue(
            poly("x").add(null).equals(
                poly("x")
            )
        );
        Assert.assertTrue(
            poly("x").add(poly("x^2")).equals(
                poly("x^2+x^1")
            )
        );
        Assert.assertTrue(
            poly("x + x").add(poly("x^2 + x + x^2")).equals(
                poly("2x^2 + 3x")
            )
        );
    }
    
    
    
    

    
    
    @Test
    public void testMul() {
        //
        Assert.assertTrue(
            poly("x").mul(poly("x")).equals(
                poly("x^2")
            )
        );
        Assert.assertTrue(
            poly("2x").mul(poly("5x")).equals(
                poly("10x^2")
            )
        );
        Assert.assertTrue(
            poly("x^3 + 2x^2 + 3x - 1").mul(poly("6x^2")).equals(
                poly("6x^5 + 12x^4 + 18x^3 - 6x^2")
            )
        );
        Assert.assertTrue(
            poly("x + 2").mul(poly("x + 3")).equals(
                poly("x^2 + 5x + 6")
            )
        );
        Assert.assertTrue(
            poly("x^2 + x").mul(poly("x + 1")).equals(
                poly("x^3 + 2x^2 + x")
            )
        );
    }
    
}
