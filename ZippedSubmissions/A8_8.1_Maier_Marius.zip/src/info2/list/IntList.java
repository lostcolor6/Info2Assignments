/*
 * OFFIZIELE 
 * Viet-Hoang Pham
 * Marius Maier
 * 
 */

package info2.list;

//import src.info2.list.IntListNode;

public class IntList {

	public static final int INVALID = Integer.MIN_VALUE;

	private IntListNode front;

	public IntList() {
		this.front = null;
	}

	/**
	 * Returns true if the list is empty.
	 */
	public boolean isEmpty() {
		return this.front == null;
	}

	/**
	 * Inserts a value at the front of list.
	 * 
	 * @param value The value that is to be inserted.
	 */
	public void addFront(final int value) {
		this.front = new IntListNode(value, this.front);
	}

	/**
	 * Recursive helper method that traverses through a list inserts a new node at
	 * the very end.
	 * 
	 * @param ptr   Current list node.
	 * @param value The value that is to be inserted.
	 */
	private static void addBackHelper(final IntListNode ptr, final int value) {
		if (ptr.hasNext()) {
			addBackHelper(ptr.next, value);
		} else {
			ptr.next = new IntListNode(value);
		}
	}

	/**
	 * Inserts a value at the end of the list.
	 * 
	 * @param value The value that is to be inserted.
	 */
	public void addBack(final int value) {
		if (this.isEmpty()) {
			this.addFront(value);
		} else {
			addBackHelper(this.front, value);
		}
	}

	/**
	 * Calculates (iteratively) the number of element within the list.
	 * 
	 * @return Number of list elements/nodes.
	 */
	public int size() {
		int ctr = 0;

		IntListNode ptr = this.front;

		while (ptr != null) {
			ctr++;
			ptr = ptr.next;
		}

		return ctr;
	}

	/**
	 * Recursive helper method for get.
	 * 
	 * @param ptr Current list node.
	 * @param i   Index of the element that is to be returned.
	 * @return Value at index i or INVALID.
	 */
	private static int getHelper(final IntListNode ptr, int i) {
		if (ptr == null) {
			return INVALID;
		} else if (i == 0) {
			return ptr.value;
		}
		return getHelper(ptr.next, i - 1);
	}

	/**
	 * Recursive variant of the get method. Returns the i-th element within the list
	 * or INVALID if the i-th element does not exist.
	 * 
	 * @param i Index of the element that is to be returned.
	 * @return Value at index i or INVALID.
	 */
	public int get(final int i) {
		return getHelper(this.front, i);
	}

	/**
	 * Own implementation of the toString-method. This method will be used
	 * automatically whenever an instance of IntList is, e.g., concatenated with a
	 * string.
	 */
	@Override
	public String toString() {
		final StringBuilder out = new StringBuilder();
		IntListNode ptr = this.front;

		while (ptr != null) {
			out.append(ptr.value);
			if (ptr.hasNext()) {
				out.append(", ");
			}
			ptr = ptr.next;
		}

		return out.toString();
	}

	// Hilfsmethode aus VL
	public void insertAt(final int i, final int value) {

		if (i == 0 || this.front == null) {
			this.front = new IntListNode(value, this.front);
			return;
		}

		IntListNode prev = this.front;
		IntListNode curr = prev.next;
		int j = i;

		while ((curr != null) && (j > 1)) {
			prev = curr;
			curr = curr.next;
			j--;
		}

		prev.next = new IntListNode(value, curr);
	}

	// ----------------------------------------------------------------
	// Exercise 1 (a)
	// ----------------------------------------------------------------

	/**
	 * Methode int find(int value), welche einen int Parameter value hat und die
	 * Liste nach dem Index des ersten Vorkommens von value durchsucht. Der Index
	 * der IntList beginnt, wie bei einem Array, bei 0.
	 * 
	 * @param value
	 * @return Index des values in der Liste
	 */

	public int find(final int value) {

		if (isEmpty()) {
			System.out.println("Fehler: leere Liste");
			return -1;
		} else {
			int listSize = size();
			for (int i = 0; i < listSize; i++) {
				if (value == get(i)) {
					return i;
				}
			}

			System.out.println("Fehler: Element nicht in Liste");
			return -1;

		}
	}

	// ----------------------------------------------------------------
	// Exercise 1 (b)
	// ----------------------------------------------------------------

	/**
	 * 
	 * Angefangen bei dem ersten Element welches auf den kleinsten Wert gesetzt
	 * wird: itterieren über Liste: wenn das i-te Element kleiner ist als das
	 * vorherige kleinste Element, so ist das i-te Element nun das kleinste Bei
	 * einer 1-Elementigen Liste ist das einzige Element selber das Kleinste.
	 * 
	 * @return das kleinste Element der Liste
	 */
	public int min() {
		if (isEmpty()) {
			System.out.println("Fehler: leere Liste");
			return IntList.INVALID;
		} else if (size() == 1) {
			return get(0);
		} else {
			int listSize = size();
			int minElement = get(0);
			for (int i = 0; i < listSize; i++) {
				int nowElement = get(i);
				if (nowElement < minElement) {
					minElement = nowElement;
				}

			}
			return minElement;
		}
	}

	// ----------------------------------------------------------------
	// Exercise 1 (c)
	// ----------------------------------------------------------------
	/**
	 * ermittelt das größte Element der Liste
	 * 
	 * @return
	 */
	public int max() {
		if (isEmpty()) {
			System.out.println("Fehler: leere Liste");
			return IntList.INVALID;
		} else if (size() == 1) {
			return get(0);
		} else {
			int listSize = size();
			int maxElement = get(0);
			for (int i = 0; i < listSize; i++) {
				int nowElement = get(i);
				if (nowElement > maxElement) {
					maxElement = nowElement;
				}

			}
			return maxElement;
		}
	}

	// ----------------------------------------------------------------
	// Exercise 1 (d)
	// ----------------------------------------------------------------

	/**
	 * Wandelt eine Liste in ein Array um (selbe Reihenfolge) -> Neues Array der
	 * Länge von der Liste wird erstellt und alle Werte werden durch forschleife
	 * rüberkopiert
	 * 
	 * @return Array mit Elementen der Liste
	 */

	public int[] asArray() {
		if (isEmpty()) {
			return new int[0];
		} else {
			int[] listArray = new int[size()];

			for (int i = 0; i < size(); i++) {
				int valueAtIndex = get(i);
				listArray[i] = valueAtIndex;
			}

			return listArray;
		}
	}

	// ----------------------------------------------------------------
	// Exercise 1 (e)
	// ----------------------------------------------------------------

	/**
	 * 
	 * Entfernt ein Element der Liste an der Stelle i
	 * 
	 * @param i Index des zu entfernenden Elements
	 * 
	 */

	public void remove(int i) {
		if (isEmpty()) {
			System.out.println("Fehler: leere Liste");
		} else if (i < 0 || i >= size()) {
			System.out.println("Fehler: Index außerhalb");
		} else if (i == 0) {
			front = front.next;
		} else {
			IntListNode davorElement = front;
			for (int j = 0; j < i - 1; j++) {
				davorElement = davorElement.next;
			}
			davorElement.next = davorElement.next.next;
		}
	}

	// ----------------------------------------------------------------
	// Exercise 1 (f)
	// ----------------------------------------------------------------

	/**
	 * Kehrt Reihenfolge der Elemente in der Liste um
	 */
	public void reverse() {
		if (isEmpty()) {
			System.out.println("Fehler: leere Liste");
		} else {
			IntListNode davorElement = null;
			IntListNode jetzigesElement = front;

			while (jetzigesElement != null) {
				IntListNode next = jetzigesElement.next;
				jetzigesElement.next = davorElement;
				davorElement = jetzigesElement;
				jetzigesElement = next;
			}

			front = davorElement;
		}
	}
}
