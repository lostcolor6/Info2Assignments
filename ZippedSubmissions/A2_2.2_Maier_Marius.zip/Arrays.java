package info2;


//OFFIZIELE VERSION ZUM KORREGIEREN! 

//Namen:
//Viet Hoang Pham
//Marius Maier

public class Arrays {
	
    // ----------------------------------------------------------------
    // Exercise 2 (a)
    // ----------------------------------------------------------------
    public static int[] intRange(final int start, final int end) {
        
        int[] new_array = new int[Math.abs(end - start) + 1]; //Neues array mit Länge von start/end bis end/start
        int j = 0;
        if (start <= end) {//array Indexe werden von start bis ende überschrieben in normaler folge (end>start)
            for (int i = start; i <= end; i++) {
            	new_array[j] = i;
                j++;
            }
        } else {
            for (int i = start; i >= end; i--) {//ansonsten von wenn (start>end) wird von start runter-iteriert
            	new_array[j] = i;
                j++;
            }
        }
        return new_array;
    }
    		
    	
    
        
        // TODO: check


        //return null;
    

    // ----------------------------------------------------------------
    // Exercise 2 (b)
    // ----------------------------------------------------------------
    public static int search(final int[] array, final int value) {
        
    	final int NOT_FOUND = -1;
        if (array.length == 0 || array == null ) { //Sonderfall von array
        	System.out.println("Fehler: array ist null oder hat keine Elemente");
        	
        }else {
        	int i = 0;
        	while ( i <= (array.length -1)) { //druchsucht nur bis zur Länge des arrays -1 wegen 1. Stelle = 0 ist in java
        		if (value == array[i]) {
        		return i;
        		}
        		i++;
        		
        	}	

        }
        
        
        
        // TODO: check

        
        

        
        return NOT_FOUND;
    }

    // ----------------------------------------------------------------
    // Exercise 2 (c)
    // ----------------------------------------------------------------
    public static void mirror(final int[] array) {
    
    	if (array == null ) { //Sonderfall von array
         	System.out.println("Fehler: array ist null");
    	 }
         
        	 
         
        	 
         else{ if (array.length != 0) {
        	 for (int i = array.length - 1; i >= array.length/2; i--) {
        		    int x = array[i];
        		    array[i] = array[array.length - 1 - i];
        		    array[array.length - 1 - i] = x;
        		}
         }
         else {
        	//{} Fall eig. bzw wird schon vom obigen geregelt
         }	 
         }
        		
        	 
        	
         
    
        // TODO: check
        
    }

    
    // ----------------------------------------------------------------
    // Exercise 2 (d)
    // ----------------------------------------------------------------
    public static void rotateLeft(final String[] array) {
        
    	 if (array == null ) { //Sonderfall von array
           	System.out.println("Fehler: array ist null");
      	 }
        
     	 else{
     		 String x = array[0]; // speichert erste Element in x
     		    for (int i = 1; i <= array.length-1; i++) {
     		        array[i - 1] = array[i]; 
     		    }
     		    array[array.length - 1] = x; 
           
     		    
     		// TODO: check    
     	 }
     	 }
         

    
    
    // ----------------------------------------------------------------
    // Exercise 2 (e)
    // ----------------------------------------------------------------
    public static void rotateRight(final String[] array) {
    	if (array == null ) { //Sonderfall von array
           	System.out.println("Fehler: array ist null");
      	 }
    	else {
    		
    	String x = array[array.length - 1]; // Speichert letztes Element in x
        for (int i = array.length - 2; i >= 0; i--) {// bei -2 Angefangen da das letzte Element an die erste Stelle geschoben wird
            array[i + 1] = array[i]; // Element um eins nach rechts
        }
        array[0] = x; 
    }
        
        // TODO: check

    }
    
    // ----------------------------------------------------------------
    // Exercise 2 (f)
    // ----------------------------------------------------------------
    public static double euclideanDistance(final double[] vec1, final double[] vec2) {

        if ((vec1 == null) || (vec2 == null)) {
            return Double.NaN;
        }
        else {
        	  
        	    double dis = 0.0;
        	    for (int i = 0; i < vec1.length; i++) {
        	         dis = dis + Math.pow(vec1[i] - vec2[i], 2);
        	         
        	    }
        	    
        	    return Math.sqrt(dis);
        	
        }
        // TODO: check

        //return 0.0;
    }
    
    // ----------------------------------------------------------------
    // Exercise 2 (g)
    // ----------------------------------------------------------------
    public static double mean(final double[] array) {
    	
    	if (array == null) {
    		System.out.println("Fehler: array ist null");
            return Double.NaN;
        }
    	else {
    	    
    	    double x = 0.0;
    	    for (int i = 0; i < array.length; i++) {
    	        x += array[i];
    	    }
    	    return x / array.length;
    	}
    		
    	
        
        // TODO: check

        //return 0.0;
    }
   
    // ----------------------------------------------------------------
    // Exercise 2 (h)
    // ----------------------------------------------------------------
    public static double stdDev(final double[] array) {
    	if ( array.length == 1) {
    		return 0.0;
    	}
    	else {

        
        double y = mean(array);
        double x = 0.0;
        for (int i = 0; i < array.length; i++) {
            x = x + Math.pow(array[i] - y, 2);
        }
        return Math.sqrt(x / (array.length - 1));
    }
        // TODO: check
        //return 0.0;
    }      

    // ----------------------------------------------------------------
    // Exercise 2 (i)
    // ----------------------------------------------------------------
    public static int[] append(final int[] array, int value) {
    	
    	if (array == null) {
    		int[] new_array = new int[] {value};
			return new_array;
           
        }
    	else {
    		int[] new_array = new int[array.length + 1]; //neues Array mit original Länge vom ersten array + 1 weil ein Wert hinzugefügt wird
    			for (int i = 0; i < array.length; i++) {
    				new_array[i] = array[i];     //Alle Indexe vom alten Array zum neuen kopiert
    			}
    			
    			new_array[new_array.length - 1] = value; // An letzter Stelle Wert eingefügt
    			return new_array;
    		}
    	
    	
        
        // TODO: check
        
        //return null;
    }       
    
    // ----------------------------------------------------------------
    // Exercise 2 (j)
    // ----------------------------------------------------------------
    public static int[] merge(final int[] array1, int[] array2) {
    	if (array1 == null && array2 == null) { //Fall beide = null
    		System.out.println("Fehler: Beide arrays sind null");
    		return array1;
    	}
    	else if (array1 == null) { //Sonderfälle falls ein null = gib das andere zurück
    		return array2;
    	}
    	else if (array2 == null) {
    		return array1;
    	}
    	else {
    		int[] new_array_merge = new int[array1.length + array2.length]; //neues Array mit Gesamtlänge von array1/2
    		for (int i = 0; i < array1.length; i++) {
    			new_array_merge[i] = array1[i]; //Überschreibt alle Indexe vom neuen array mit denen von array1
    		}
    		for (int i = 0; i < array2.length; i++) {
    			new_array_merge[i + array1.length] = array2[i]; //Überschreibt indexe ab der Stelle wo die Indexe von 1 aufhören mit denen von array2
    		}
			return new_array_merge;
        
        // TODO: check
    	}
        //return null;
    }   
    
    // ----------------------------------------------------------------
    // Exercise 2 (k)
    // ----------------------------------------------------------------
    public static int[] mergeInterleaved(final int[] array1, int[] array2) {
    	
    
    	if (array1 == null && array2 == null) { //Fall beide = null
    		System.out.println("Fehler: Beide arrays sind null");
    		return array1;
    	}
    	else if (array1 == null) { //Sonderfälle falls ein null = gib das andere zurück
    		return array2;
    	}
    	else if (array2 == null) {
    		return array1;
    	}
    	else {
    		int[] new_array_merge = new int[array1.length + array2.length]; //neues Array mit Gesamtlänge von array1/2
    		int i = 0;
    		int j = 0;
    		int y = 0;
    		while (i < array1.length && j < array2.length) {
    			new_array_merge[y++] = array1[i++];
    			new_array_merge[y++] = array2[j++];
    			/*
    			i++;
    			j++;
    			y++;
    			*/
    	    }
    	    while (i < array1.length) {
    	    	new_array_merge[y++] = array1[i++];
    	    	/*
    	    	y++;
    	    	i++;
    	    	*/
    	    }
    	    while (j < array2.length) {
    	    	new_array_merge[y++] = array2[j++];
    	    	/*
    	    	y++;
    	    	j++;
    	    	*/
    	    }
    		return new_array_merge;
    		
    	}
        // TODO: Implement me.

        //return null;
    }   
    
    // ----------------------------------------------------------------

    public static String DELIMITER = ", ";
    
    //
    // Helper function for converting int-arrays into strings.
    //
    public static String asString(final int[] array) {
        if (array == null) { return "null"; }

        final StringBuilder out = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            if (i > 0) {
                out.append(DELIMITER);
            }
            out.append(String.valueOf(array[i]));
        }
        return out.toString();
    }
    
    //
    // Helper method for converting double-arrays into strings.
    //
    public static String asString(final double[] array) {
        if (array == null) { return "null"; }

        final StringBuilder out = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            if (i > 0) {
                out.append(DELIMITER);
            }
            out.append(String.valueOf(array[i]));
        }
        return out.toString();
    }
    
    //
    // Helper method for converting double-arrays into strings.
    //
    public static String asString(final String[] array) {
        if (array == null) { return "null"; }

        final StringBuilder out = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            if (i > 0) {
                out.append(DELIMITER);
            }
            out.append(String.valueOf(array[i]));
        }
        return out.toString();
    }
    
    public static void main(String[] args) {
        
        // ----------------------------------------------------------------
        // Exercise 2 (a)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (a) --------");
            System.out.println();
            System.out.println("int range from 0 to 10");
            System.out.println(asString(intRange(0, 10)));
            System.out.println();
            System.out.println("int range from 12 to 3");
            System.out.println(asString(intRange(12, 3)));
            System.out.println();
            System.out.println("int range from -5 to 5");
            System.out.println(asString(intRange(-5, 5)));
            System.out.println();
            System.out.println("int range from 5 to -5");
            System.out.println(asString(intRange(5, -5)));
            System.out.println();
            //System.out.println(asString(data, ", "));
            System.out.println();
        } 
        
        // ----------------------------------------------------------------
        // Exercise 2 (b)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (b) --------");
            System.out.println();

            final int[] array = {6, 3, 9, 2, 4, 7, 1, -4, 8};
            System.out.println(asString(array));

            final int [] tests = {7, -4, -2, 6, 8, 12};
            for (int i = 0; i < tests.length; i++) {
            
                final int value = tests[i];
                final int index = search(array, value);

                if (index >= 0) {
                System.out.println("found " + value + " at " + index);
                } else {
                    System.out.println("value " + value + " not found");
                }
            }
            System.out.println();
        } 
        
        
        // ----------------------------------------------------------------
        // Exercise 2 (c)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (c) --------");
            System.out.println();
            final int[] array1 = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
            System.out.println(asString(array1));
            mirror(array1);
            System.out.println(asString(array1));
            mirror(array1);
            System.out.println(asString(array1));
            System.out.println();
            final int[] array2 = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
            System.out.println(asString(array2));
            mirror(array2);
            System.out.println(asString(array2));
            mirror(array2);
            System.out.println(asString(array2));
            System.out.println();

            final int[] array3 = {8};
            System.out.println(asString(array3));
            mirror(array3);
            System.out.println(asString(array3));
            mirror(array3);
            System.out.println(asString(array3));
            System.out.println();
        } 

        // ----------------------------------------------------------------
        // Exercise 2 (d)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (d) --------");
            System.out.println();
            
            final String[] array = {"bar", "idx", "xyz", "uvw", "abc", "dfg", "mau", "foo"};
            
            System.out.println(asString(array));
            rotateLeft(array);
            System.out.println(asString(array));
            rotateLeft(array);
            System.out.println(asString(array));
            rotateLeft(array);
            System.out.println(asString(array));
            
            System.out.println();
        }
        
        // ----------------------------------------------------------------
        // Exercise 2 (e)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (e) --------");
            System.out.println();
            
            final String[] array = {"bar", "idx", "xyz", "uvw", "abc", "dfg", "mau", "foo"};
            
            System.out.println(asString(array));
            rotateRight(array);
            System.out.println(asString(array));
            rotateRight(array);
            System.out.println(asString(array));
            rotateRight(array);
            System.out.println(asString(array));
            
            System.out.println();
        }
        
        // ----------------------------------------------------------------
        // Exercise 2 (f)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (f) --------");
            System.out.println();
            
            final double[] vec1 = {0, 0, 0};
            final double[] vec2 = {
                Math.sqrt(1.0 / 3.0), Math.sqrt(1.0 / 3.0), Math.sqrt(1.0 / 3.0)
            };
            
            System.out.println(asString(vec1));
            System.out.println(asString(vec2));
            System.out.println("distance " + euclideanDistance(vec1, vec2));
            System.out.println();

            final double[] vec3 = {1.0,  2.0,  3.0,  4.0, 5.0, 6.0};
            final double[] vec4 = {0.1, -2.0, -1.0, -0.6, 1.0, 3.0};

            System.out.println(asString(vec3));
            System.out.println(asString(vec4));
            System.out.println("distance : " + euclideanDistance(vec3, vec4));
            System.out.println();
        }
        
        // ----------------------------------------------------------------
        // Exercise 2 (g + h)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (g + h) --------");
            System.out.println();
            
            final double[] array1 = {1.0, 0.9, 0.8, 0.85, 1.1, 1.2, 1.15};
            
            System.out.println(asString(array1));
            System.out.println("mean   : " + mean(array1));
            System.out.println("stddev : " + stdDev(array1));
            System.out.println();

            final double[] array2 = {5.0};
            
            System.out.println(asString(array2));
            System.out.println("mean   : " + mean(array2));
            System.out.println("stddev : " + stdDev(array2));
            System.out.println();
        }
        
        // ----------------------------------------------------------------
        // Exercise 2 (i)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (i) --------");
            System.out.println();
            
            int[] array = null;
            
            array = append(array, 10);
            array = append(array, 20);
            array = append(array, 30);
            array = append(array, 40);
            array = append(array, 50);
            array = append(array, 60);
            array = append(array, 70);
            
            System.out.println(asString(array));

            System.out.println();
        }
        
        // ----------------------------------------------------------------
        // Exercise 2 (j)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (j) --------");
            System.out.println();
            
            int[] array1 = null;
            int[] array2 = {1, 2, 3, 4};
            int[] array3 = {10, 20, 30, 40, 50};

            System.out.println(asString(array1));
            System.out.println(asString(array2));
            System.out.println(asString(array3));
            
            array1 = merge(array1, array2);
            array1 = merge(array2, array3);
            
            System.out.println(asString(array1));
            
            array1 = merge(array1, array1);
            
            System.out.println(asString(array1));
            
            System.out.println();
        }
        
        // ----------------------------------------------------------------
        // Exercise 2 (k)
        // ----------------------------------------------------------------
        {
            System.out.println("-------- Exercise 2 (k) --------");
            System.out.println();
            
            final int[] array1 = {2, 4, 6, 8, 10, 12};
            final int[] array2 = {100, 200, 300, 400, 500, 600};
            
            final int[] array3 = mergeInterleaved(array1, array2);
            
            System.out.println(asString(array1));
            System.out.println(asString(array2));
            System.out.println(asString(array3));
            
            System.out.println();

            final int[] array4 = {1, 2, 3, 4};
            final int[] array5 = {10, 20, 30, 40, 50, 60};
            
            final int[] array6 = mergeInterleaved(array4, array5);
            
            System.out.println(asString(array4));
            System.out.println(asString(array5));
            System.out.println(asString(array6));
            
            System.out.println();

        }
        
    }

}
