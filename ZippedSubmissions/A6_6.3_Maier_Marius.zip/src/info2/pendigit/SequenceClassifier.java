/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 6
Viet-Hoang_Pham
Marius Maier
*/

package info2.pendigit;

/**
 * "SequenceClassifier" verfügt über ein Zustand/Gedächtnis Durch das Gedächtnis
 * lassen sich einzelne Datenpunkte einer Zeitreihe, die nach und nach an den
 * SequenceClassifier ubergeben werden, miteinander in Verbindung setzen.
 *
 */

public interface SequenceClassifier extends Classifier {

	/**
	 * Setzt den Zustand von "SequenceClassifier" zurück
	 */
	public void reset();

}
