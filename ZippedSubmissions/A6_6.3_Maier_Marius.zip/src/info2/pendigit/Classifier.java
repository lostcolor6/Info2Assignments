/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 6
Viet-Hoang_Pham
Marius Maier
*/

package info2.pendigit;

/**
 * Schäzt auf Basis einer Eingabe zu welcher Kategorie aus einer Menge von
 * vorgegebenen Kategorien das ”Gesehene“/die Eingabe gehört. Bsp; Eingabe Bild
 * Unterscheidung; Hund/Katze im Bild.
 * 
 * 
 * 
 *
 */

public interface Classifier {

	public int getInputSize();

	public int getOutputSize();

	/**
	 * Klassifikation wird durch Aufruf von "predict" realisiert
	 * 
	 * @param ein double array
	 * @return ein double array mit genau getOutputSize()-viele Werte. Werte selbst:
	 *         Wahrscheinlichkeitsverteilung Jeder Index repräsentiert hierbei eine
	 *         Kategorie (Hier:die Ziffern 0 bis 9)
	 */
	public double[] predict(double[] input);
		
	

}
