/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 6
Viet-Hoang_Pham
Marius Maier
*/


package info2.pendigit;

/**
 * "AbstractClassifier" teil-implementiert Interface "Classifier" (beiden
 * Get-Methoden)
 */
public abstract class AbstractClassifier implements Classifier {

	private int inputSize;

	private int outputSize;

	/**
	 * Konstruktor für Teil-Implementation
	 * 
	 * @param InputSize
	 * @param outputSize
	 */
	public AbstractClassifier(int InputSize, int outputSize) {

	}

	/**
	 * Getter für Inputsize
	 * 
	 * @return inputSize
	 */
	public int getInputSize() {
		return this.inputSize;
	}

	/**
	 * Getter für Outputsize
	 * 
	 * @return outputSize
	 */
	public int getOutputSize() {
		return this.outputSize;
	}
}
