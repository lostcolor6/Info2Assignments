/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 6
Viet-Hoang_Pham
Marius Maier
*/

package info2.pendigit;

import de.jannlab.Net;
import de.jannlab.generator.GenerateNetworks;
import info2.pendigit.misc.LSTMTools;

/**
 * Klasse kann nicht weitervererbt werden (Keine Unterklassen von
 * LSTMClassifier).
 * 
 */

public final class LSTMClassifier extends AbstractClassifier implements SequenceClassifier {

	// Neue Instanz vom Typ de.jannlab.Net
	private de.jannlab.Net net;
	final static int inputSize = 3;
	final static int outputSize = 10;

	/**
	 * 1.Erzeugen vom Neuronale Netz 2.Speichern des Netzes in Instanzvariable
	 * this.net 3.Laden der Gewichte
	 */
	public LSTMClassifier() {
		super(inputSize, outputSize);

		// Erzeugen vom Neuronale Netz
		final String netDescriptor = LSTMTools.var("LSTM-#1-tanh32-softmax#2", inputSize, outputSize);

		// Speichern des Netzes in Instanzvariable this.net
		 this.net = GenerateNetworks.generateNet(netDescriptor);

		// Laden der Gewichte
		final double[] weights = LSTMTools.loadWeights("info2/pendigit/resources/" + netDescriptor + ".weights");
		net.writeWeights(weights, 0);

	}

	final double[] input = new double[inputSize];
	final double[] output = new double[outputSize];
	

	/**
	 * 
	 *  
	 */
	public double[] predict(double[] input) {
		if (input.length == 3) {
			this.net.input(input, 0);
			this.net.compute();
			this.net.output(output, 0);
			return output;
		} else {

			double[] zeroArray = new double[10];
			for (int i = 0; i < zeroArray.length; i++) {
				zeroArray[i] = 0.0;
			}
			return zeroArray;
		}

	}

	/**
	 * 
	 * 
	 */
	public void reset() {
		this.net.reset();
	}

	/**
	 * 
	 * Getter für net vom Typ Net
	 * 
	 * @return net
	 */
	public Net getNet() {
		return this.net;
	}

}



