package info2;



//Namen:
//Viet Hoang Pham
//Marius Maier

public class AnimalSpotting {

    // ----------------------------------------------------------------
    // Exercise 1 (b)
    // ----------------------------------------------------------------
    public static Animal[] generateRandomZoo(int n) {
    	Animal[] xa = new Animal[n];
    	for (int i = 0; i < n; i++) {
    		int r = RandomTools.randomValue(Animal.values().length); //Random Zahl von 0 bis Länge von Animal
    		
    		Animal tierNr = Animal.values()[r]; 
    		xa[i]= tierNr; //Zuweisung zu den Indexen vom neuen array
    		
    	}
    	
    	return xa;
    // TODO: check
    
    }
    
    
    // ----------------------------------------------------------------
    // Exercise 1 (c)
    // ----------------------------------------------------------------
    public static void printZoo(Animal[] zoo) {
    	if (zoo == null) { //Sonderfall
    		System.out.println();
    	}
    	else {
    		for (int i = 0; i < zoo.length ; i++) {
    			System.out.println(zoo[i]);	
    		}
    		
    	}
    }
    // TODO: check
    
    
    
    // ----------------------------------------------------------------
    // Exercise 1 (d)
    // ----------------------------------------------------------------
    public static int[] countAnimals(Animal[] zoo) {
    	if ( zoo == null || zoo.length == 0) { //Sonderfall
    		int[] nix = new int[Animal.values().length];
    		return nix;
    	}
    	else {
         int[] tier_anzahl = new int[Animal.values().length]; //neues array der Länge von Animal

    		    for (Animal tier : zoo) { //Vergleich tier in Animal / tier in zoo
    		        int o = tier.ordinal();
    		        tier_anzahl[o]++; //Für jeden Treffer +1
    		
    		}
    		    return tier_anzahl;
    	   }
    	 
    	
    }
    // TODO: check
    
    
    
    // ----------------------------------------------------------------
    // Exercise 1 (e)
    // ----------------------------------------------------------------
    public static Animal mostFrequentAnimal(Animal[] zoo) {
    	if ( zoo == null) { //Sonderfall
    		return null;
    	}
    	else if (zoo.length == 0) {
    		return Animal.values()[0];
    	}
    	else {
    		int[] px = countAnimals(zoo);
    		int i_biggest = 0;
    		  for ( int i = 1; i < px.length; i++ ) { //Von einem Array mit gezählten Tieren Index von größter Zahl rausfinden
    		   if ( px[i] > px[i_biggest] ) {
    			   i_biggest = i;
    		   }
    		   else if (px[i] == px[i_biggest]) {
                   if (Animal.values()[i].ordinal() < Animal.values()[i_biggest].ordinal()) {
                       i_biggest = i;
    	   
    		   }
    		   }
    		  
    		}
    		  return Animal.values()[i_biggest]; 
    	}
    }
    
    // TODO: --// 2 TiERE FALL INDEX VOM KLEINEREN 

    

    // ----------------------------------------------------------------
    // Exercise 1 (f)
    // ----------------------------------------------------------------
    public static double calculateBiomass(Animal[] zoo) {
    	double Gewicht = 0.0;
    	
    	for (Animal tier : zoo) {
    		
    	
    		switch(tier){
            case ELEPHANT:
                Gewicht = Gewicht + 5000;
                break;
            case LION:
            	Gewicht = Gewicht + 150;
                break;
            case TIGER:
            	Gewicht = Gewicht + 200;
                break;
            case WASP:
            	Gewicht = Gewicht + 6e-5;
                break;
            case SNAKE:
            	Gewicht = Gewicht + 35;
                break;
            case MONKEY:
            	Gewicht = Gewicht + 160;
                break;
            case EMU:
            	Gewicht = Gewicht + 40;
                break;
            default:
                Gewicht = Gewicht + 0; //null wird übersprungen
                break;
               
    		}
    		
    	}
    	return Gewicht;
    }
    // TODO: Implement calculateBiomass



    // ----------------------------------------------------------------
    
    public static void main(String[] args) {

        Animal[] zoo = generateRandomZoo(100);
        
        printZoo(zoo);
        
        System.out.println();
        
        int[] counting = countAnimals(zoo);
        System.out.println(ArrayTools.asString(counting));
        System.out.println();
        
        System.out.println(mostFrequentAnimal(zoo));
        
        System.out.println();
        
        System.out.println(calculateBiomass(zoo));
    	
    	
    	
    	
    }
    
}