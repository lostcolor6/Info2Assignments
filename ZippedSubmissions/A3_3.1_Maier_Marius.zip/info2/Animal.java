package info2;

//OFFIZIELE VERSION ZUM KORREGIEREN! 

//Namen:
//Viet Hoang Pham
//Marius Maier

public enum Animal {
ELEPHANT,
LION,
TIGER,
WASP,
SNAKE,
MONKEY,
EMU;


	}


