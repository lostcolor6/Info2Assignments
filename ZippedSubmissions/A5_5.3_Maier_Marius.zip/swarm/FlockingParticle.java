package info2.swarm;

/*
OFFIZIELLE VERSION
ÜBUNGSBLATT 5
Viet-Hoang_Pham
Marius Maier
*/

public class FlockingParticle extends Particle {
	// Spezialkonstruktor
	public FlockingParticle(Swarm swarm) {
		this.swarm = swarm;

	}

	public static final double DEFAULT_OUTER_DIST = 0.3;
	public static final double DEFAULT_INNER_DIST = 0.09;
	public static final double DEFAULT_COHESION_RATE = 0.25;
	public static final double DEFAULT_ALIGNMENT_RATE = 0.25;
	public static final double DEFAULT_SEPARATION_RATE = 0.6;

	private Swarm swarm;
	private double outerDist = DEFAULT_OUTER_DIST;
	private double innerDist = DEFAULT_INNER_DIST;
	private double cohesionRate = DEFAULT_COHESION_RATE;
	private double alignmentRate = DEFAULT_ALIGNMENT_RATE;
	private double separationRate = DEFAULT_SEPARATION_RATE;

	/**
	 * Returns value of outer distance
	 * 
	 * @return outerDist
	 */
	public double getouterDist() {
		return this.outerDist;
	}

	/**
	 * Sets value of outer distance
	 * 
	 * @return new set value of outerDist
	 */
	public void setouterDist(double outerDist) {
		this.outerDist = outerDist;
	}

	/**
	 * Returns value of inner distance
	 * 
	 * @return innerDist
	 */
	public double getinnerDist() {
		return this.innerDist;
	}

	/**
	 * Sets value of inner distance
	 * 
	 * @return new set value of innerDist
	 */
	public void setinnerDist(double innerDist) {
		this.innerDist = innerDist;
	}

	/**
	 * Returns value of cohesion rate
	 * 
	 * @return cohesionRate
	 */
	public double getcohesionRate() {
		return this.cohesionRate;
	}

	/**
	 * Sets value of cohesion rate
	 * 
	 * @return new set value of cohesionRate
	 */
	public void setcohesionRate(double cohesionRate) {
		this.cohesionRate = cohesionRate;
	}

	/**
	 * Returns value of alignment rate
	 * 
	 * @return alignmentRate
	 */
	public double getalignmentRate() {
		return this.alignmentRate;
	}

	/**
	 * Sets value of alignment rate
	 * 
	 * @return new set value of alignmentRate
	 */
	public void setalignmentRate(double alignmentRate) {
		this.alignmentRate = alignmentRate;
	}

	/**
	 * Returns value of seperation rate
	 * 
	 * @return seperationRate
	 */
	public double getseparationRate() {
		return this.separationRate;
	}

	/**
	 * Sets value of seperation rate
	 * 
	 * @return new set value of seperationRate
	 */
	public void setseparationRate(double separationRate) {
		this.separationRate = separationRate;
	}

	/*
	 * Festlegung des Schwarmverhaltens/ Richtung in der sich das nächste Particle
	 * bewegen soll
	 * 
	 * Return: ein Kraftvektor in Form einer Instanz vom Typ Vector2d
	 */
	@Override
	public Vector2d calculateParticleForce() {
		super.calculateParticleForce();

		return SwarmTools.calculateFlockingForce(new Particle(), swarm, getouterDist(), getinnerDist(), getMaxSpeed(),
				getMaxForce(), getcohesionRate(), getalignmentRate(), getseparationRate());

	}
}

