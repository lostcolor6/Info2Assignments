/*
 * OFFIZIELE 
 * Viet-Hoang Pham
 * Marius Maier
 * 
 */

package info2.recursion;

public class RecursiveMath {

    
    public static int incr(int a) {
        return a + 1;
    }
    
    public static int decr(int a) {
        return a - 1;
    }
    
    // ----------------------------------------------------------------
    // Exercise 7.1 a
    // ----------------------------------------------------------------
	/**
	 * Methode "add" addiert zwei ints zusammen.
	 * b = 0 ist der Abbruchfall und gleichzeitig auch der Fall falls a und b  = 0 sind
	 * wenn b > 0 ist, wird a so oft um 1 hochgezählt wie b runtergezählt wird.
	 * wenn b < 0 ist, wird b so oft um 1 hochgezählt wie a runtergezählt wird.
	 * @param a
	 * @param b
	 * @return a + b
	 */
   
	public static int add(int a, int b) {
		if (b == 0) {
			return a;
		} 
		else if (a == 0) {
			return b;
		}

		else if (b > 0) {

			return add(incr(a), decr(b));
		} else

		{
			return add(decr(a), incr(b));
		}
	}
	
    
    // ----------------------------------------------------------------
    // Exercise 7.1 b
    // ----------------------------------------------------------------
   /* public static int sub(int a, int b) {
       if (b == 0) {
    	   return a;   
       }       
       else if (b > 0) {
    	   
    		   return sub(decr(a), decr(b));    	  
       }
       else if (b < 0) {
    	   if (a > b) {
    		 
    		   
    		   return sub(decr(a), incr(b));   
    		   
    	   } else {
    	   return sub(incr(a), incr(b));
    	   }
       }

       else {
    	   return sub(decr(a), incr(b));
       }
       
    }*/
  
    public static int sub(int a, int b) {
        if (b == 0) {
            return a;
        } else if (b > 0) {
            return sub(decr(a), decr(b));
        } else {
            return sub(incr(a), incr(b));
        }
    }

    
    
    // ----------------------------------------------------------------
    // Exercise 7.1 c
    // ----------------------------------------------------------------
    public static int mul(int a, int b) {
        // TODO: Implement me.
        return 0;
    }
    
    // ----------------------------------------------------------------
    // Exercise 7.1 d
    // ----------------------------------------------------------------
    public static int div(int a, int b) {
        // TODO: Implement me.
        return 0;
    }
    
    public static void main(String[] args) {
    	//TEST-WERTE für add
    	System.out.println("Test add:");
		System.out.println(add(2, 2));
		System.out.println(add(2, 4));
		System.out.println(add(4, 2));
		System.out.println(add(-2, 2));
		System.out.println(add(2, -2));
		System.out.println(add(0, 0));
		System.out.println(add(0, 2));
		System.out.println(add(2, 0));
		System.out.println(add(0, -2));
		System.out.println(add(-2, 0));
		
		//TEST-WERTE für sub
		System.out.println("Test sub:");
		System.out.println(sub(2, 2));
		System.out.println(sub(2, 4));
		System.out.println(sub(4, 2));
		System.out.println(sub(-2, 2));
		System.out.println(sub(2, -2)); 
		System.out.println(sub(0, 0));
		System.out.println(sub(0, 2));
		System.out.println(sub(2, 0));
		System.out.println(sub(0, -2)); 
		System.out.println(sub(-2, 0));
	}
  

}
