package info2;

import info2.robotarm.RobotArmController;
import info2.robotarm.RobotArmSimulation;

public class RobotArmMotionPlanner {

    public static final int POINTS_MAX_NUM = 5;
    
    private Point[] controlPoints = new Point[POINTS_MAX_NUM];

    private int pointsNum = 0;
    private int nextPoint = -1;
    private RobotArmController controller;

    public int getPointsNum() {
        return this.pointsNum;
    }
    
    public int getNextPoint() {
        return this.nextPoint;
    }
    
    public RobotArmController getController() {
        return this.controller;
    }
    
    public RobotArmMotionPlanner(final RobotArmController controller) {
        this.controller = controller;
    }
    
	// ----------------------------------------------------------------
	// Exercise 2 (b)
	// ----------------------------------------------------------------
	public void addControlPoint(final double x, final double y) {

		Point k = new Point(x, y); // Erzeugung einer neuen Point-Instanz
		if (pointsNum < POINTS_MAX_NUM) {
			controlPoints[pointsNum] = k; // Speicherung des Punktes an die nächst freie Stelle im Array "controlPoints"
			pointsNum++;// Nach jedem neuen Punkt erhöt sich der Wert um pointsNum um 1
		}

	}

	// ----------------------------------------------------------------
	// Exercise 2 (c)
	// ----------------------------------------------------------------
	public Point getControlPoint(final int i) { // gibt den jeweiligen Inhalt des Indexes i aus dem Array
												// "controlPoints"
		if (i >= 0 && i < pointsNum) {
			return controlPoints[i];

		} 
		else {
			return null;
		}

	}

	// ----------------------------------------------------------------
	// Exercise 2 (d)
	// ----------------------------------------------------------------
	public int performMotion() {
		int p = 0;

		for (int i = 0; i < POINTS_MAX_NUM; i++) {
			nextPoint = i;

			boolean o = this.controller.navigateToTarget(getControlPoint(i)); // Instanz der Klasse RobotArmController
			// "Der Methodenaufruf wird solange blockieren, bis der Roboterarm das Ziel so
			// gut es geht angesteuert hat"
			// gibt boolean-Wert raus je nach erreichen des Zeieles

			if (o) {
				p++; // Zählen der erfolgreich angesteuerten Zielpunkte
			}
			else {
			}

		}
		pointsNum = 0; // Alle Punkte abgearbeitet -> Reset der Werte
		nextPoint = -1;
		return p;
	}

	public static void main(String[] args) {

		RobotArmController controller = new RobotArmController();
		RobotArmMotionPlanner planner = new RobotArmMotionPlanner(controller);

		RobotArmSimulation.runSimulation(planner);

	}
}