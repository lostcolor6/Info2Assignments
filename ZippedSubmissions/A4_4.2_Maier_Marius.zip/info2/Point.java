package info2;

public class Point {
	// private Instantz Variabeln
	private double x;
	private double y;

//spezial Konstruktor
	public Point(double x1, double y1) {
		x = x1;
		y = y1;

	}

//Standartkonstruktor
	public Point() {
		x = 0;
		y = 0;
	}

//Getter X Y	
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

//Setter X Y
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

//erzeugt Array mit x y;
	public double[] toArray() {
		double[] xyArray = { this.x, this.y };
		return xyArray;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
