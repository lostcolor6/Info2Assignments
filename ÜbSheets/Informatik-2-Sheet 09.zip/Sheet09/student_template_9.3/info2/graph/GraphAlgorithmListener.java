package info2.graph;

/**
 * This listener interface has to be implemented by interested
 * graph algorithm observers. This is mainly used for visualization
 * purposes.
 * 
 * @author Sebastian Otte
 */
public interface GraphAlgorithmListener {
    /**
     * This method shall be invoked whenever the graph algorithm
     * of interest makes a "major step" (e.g. one iteration of the
     * main loop etc.)
     */
    public void update();
    /**
     * Informs the listener that the given node was visited. 
     * @param node Node of interest.
     */
    public void notifyVisited(final Node node);
    /**
     * Informs the listener that the given edge was visited. 
     * @param node Edge of interest.
     */
    public void notifyVisited(final Edge edge);
    /**
     * Informs the listener that the given edge is part of the 
     * (potential) solution. 
     * @param node Edge of interest.
     */
    public void notifySolution(final Edge edge);
    
}


