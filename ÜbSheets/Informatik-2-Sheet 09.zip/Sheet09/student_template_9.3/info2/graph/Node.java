package info2.graph;

import info2.graph.tools.DynArray;
import info2.graph.tools.Vector2d;

/**
 * A simple graph node class representing nodes within an 2d
 * euclidean graph. A graph node contains an element (here an
 * instance of the well-known class Vector2d) and an arbitrary
 * number of edges connecting the current node to other nodes
 * (neighbors). The set of edges is here represented using the
 * generic class DynArray.
 * 
 * @author Sebastian Otte
 */
public class Node {
    
    public final Vector2d vertex;
    public final DynArray<Edge> edges;
    
    public int tag;
    public double value;
    
    public Node(final Vector2d vertex) {
        this.vertex = vertex;
        this.edges = new DynArray<>();
    }
    
    /**
     * Returns an instance of DynArray<Node> that
     * contains all neighbor nodes of the current node. 
     * @return Instance of DynArray<Node>.
     */
    public DynArray<Node> getNeighbors() {
        DynArray<Node> neighbors = new DynArray<Node>();
        for (int i = 0; i < this.edges.getSize(); i++) {
            final Edge edge = this.edges.get(i);
            neighbors.add(edge.other(this));
        }
        return neighbors;
    }
    
    /**
     * Returns an instance of class Edge, that is, the corresponding
     * edge if the current note is connected with the other node.
     * If there is no edge between the nodes null is returned.
     * @param other The potential neighbor node.
     * @return Instance of Edge.
     */
    public Edge neighborEdge(final Node other) {
        for (int i = 0; i < edges.getSize(); i++) {
            final Edge edge = edges.get(i);
            if (edge.other(this) == other) {
                return edge;
            }
        }
        return null;
    }
    
    /**
     * Return true, if the current node is connected to the other node.
     * @param other The potential neighbor node.
     */
    public boolean isNeighbor(final Node other) {
        return this.neighborEdge(other) != null;
    }
    
}