package info2.graph;

import java.util.Random;

import info2.graph.gui.GraphAlgorithmGUI;
import info2.graph.tools.DynArray;
import info2.graph.tools.GraphTools;
import info2.graph.tools.Vector2d;

public class Dijkstra implements GraphAlgorithm {

    private Graph graph;
    private Node start;
    private Node end;
    private DynArray<Node> nodes;
    
    public Dijkstra() {
        this.graph = null;
        this.start = null;
        this.end = null;
    }
    
    @Override
    public void initialize(
        final Graph graph, final Node start, final Node end
    ) {
        this.graph = graph;
        this.start = start;
        this.end = end;
        //
        //  TODO: implement me.
        //
        
    }
    
    @Override
    public void perform(
        final GraphAlgorithmListener listener
    ) {
        //
        boolean foundGoal = false;
        //
        // Disjktra main loop.
        //
        while ((this.nodes.getSize() > 0) && (!foundGoal)) {
            //
            //  TODO: implement me.
            //
            
            listener.update();
        }
        
        //
        // Extract solution (matk edges as solution).
        //
        // ...
    }
    
    public static void main(String[] args) {
        //
        // Your final implementation shall be able to run this code and find
        // the shortest path between arbitrary nodes.
        //
        final Random rnd = new Random(1234);
        final GraphAlgorithm algorithm = new Dijkstra();
        final Graph graph = GraphTools.generateRandomGraph(rnd, 200, 1.0, 1.0, 0.05);    
        final GraphAlgorithmGUI gui = new GraphAlgorithmGUI(graph, algorithm);
        gui.show();
    }}


