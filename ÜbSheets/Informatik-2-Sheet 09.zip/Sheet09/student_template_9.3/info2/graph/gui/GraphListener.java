package info2.graph.gui;

import info2.graph.Graph;

public interface GraphListener {
    public void onUpdate(final Graph graph);
}