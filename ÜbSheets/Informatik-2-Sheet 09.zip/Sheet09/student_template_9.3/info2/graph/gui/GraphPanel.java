package info2.graph.gui;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import info2.graph.Edge;
import info2.graph.Graph;
import info2.graph.Node;
import info2.graph.tools.Vector2d;

public class GraphPanel extends JPanel implements GraphListener, MouseListener {
    private static final long serialVersionUID = 100806644814083864L;

    public static final int MARGIN = 20;
    
    public static final int PANEL_WIDTH  = 800;
    public static final int PANEL_HEIGHT = 600;
    
    public static final int NODE_RADIUS = 5; 
    public static final Stroke THIN_STROKE = new BasicStroke(1.0f);
    public static final Stroke MEDIUM_STROKE = new BasicStroke(1.5f);
    public static final Stroke THICK_STROKE = new BasicStroke(3.0f);

    public static final Color COLOR_EDGE = new Color(150, 150, 150);
    public static final Color COLOR_EDGE_VISITED = new Color(200, 75, 75);
    public static final Color COLOR_EDGE_SOLUTION = new Color(50, 200, 100);

    public static final Color COLOR_NODE = new Color(150, 150, 150);
    public static final Color COLOR_NODE_VISITED = new Color(75, 75, 75);
    public static final Color COLOR_NODE_BORDER = new Color(255, 255, 255);
    public static final Color COLOR_NODE_BORDER_VISITED = new Color(150, 150, 150);
    
    public static final double NODE_RADIUS_NORM = 2.2 * (
        (double)(NODE_RADIUS) / (double)Math.max(PANEL_WIDTH, PANEL_HEIGHT)
    );
    
    private int width;
    private int height;
    private int sleep;
    
    private Graph graph;
    private BufferedImage renderBuffer;
    private Graphics2D renderBufferContext;
    
    private Node start;
    private Node end;
    
    private List<Node> visitedNodes;
    private List<Edge> visitedEdges;
    private List<Edge> solutionEdges;
     
    private List<GraphPanelListener> listeners;
    
    public void reset() {
        this.start = null;
        this.end = null;
        this.resetMarks();
    }
    
    public void resetMarks() {
        this.visitedNodes.clear();
        this.visitedEdges.clear();
        this.solutionEdges.clear();
    }
    
    public void setStart(final Node node) {
        this.start = node;
    }
    
    public void setEnd(final Node node) {
        this.end = node;
    }
    
    public void markVisited(final Node node) {
        if (!this.visitedNodes.contains(node)) {
            this.visitedNodes.add(node);
        }
    }

     public void markVisited(final Edge edge) {
        if (!this.visitedEdges.contains(edge)) {
            this.visitedEdges.add(edge);
        }
    }

    public void markSolution(final Edge edge) {
        if (!this.solutionEdges.contains(edge)) {
            this.solutionEdges.add(edge);
        }
    }

    
    public GraphPanel(final Graph graph, final int sleep) {
        //
        this.graph = graph;
        this.sleep = sleep;
        this.height = PANEL_HEIGHT + 2 * MARGIN;
        this.width = PANEL_WIDTH + 2 * MARGIN;
        //
        this.listeners = new ArrayList<>();
        this.visitedNodes = new ArrayList<>();
        this.visitedEdges = new ArrayList<>();
        this.solutionEdges = new ArrayList<>();
        //
        final Dimension d = new Dimension(this.width, this.height);
        this.setPreferredSize(d);
        this.setMinimumSize(d);
        this.setMaximumSize(d);
        this.setSize(d);
        //
        // initialize render buffers.
        //
        this.renderBuffer = new BufferedImage(
            this.width, this.height,
            BufferedImage.TYPE_INT_ARGB
        );
        this.renderBufferContext = (Graphics2D)this.renderBuffer.createGraphics();
        this.renderBufferContext.setRenderingHint(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON
        );
        this.renderBufferContext.setRenderingHint(
            RenderingHints.KEY_ALPHA_INTERPOLATION,
            RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY
        );
        this.renderBufferContext.setRenderingHint(
            RenderingHints.KEY_COLOR_RENDERING,
            RenderingHints.VALUE_COLOR_RENDER_QUALITY
        );
        this.renderBufferContext.setRenderingHint(
            RenderingHints.KEY_DITHERING,
            RenderingHints.VALUE_DITHER_ENABLE
        );
        this.renderBufferContext.setRenderingHint(
            RenderingHints.KEY_INTERPOLATION,
            RenderingHints.VALUE_INTERPOLATION_BICUBIC
        );
        this.renderBufferContext.setRenderingHint(
            RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_QUALITY
        );
        //
        this.addMouseListener(this);
    }
    
    private final void repaintRenderBuffer() {
        final Graphics2D g = this.renderBufferContext;
        //
        // Draw background.
        //
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, this.width, this.height);
        
        g.setStroke(MEDIUM_STROKE);
        
        for (int i = 0; i < this.graph.getEdgesNum(); i++) {
            final Edge edge = this.graph.getEdge(i);
            
            final int cx1 = MARGIN + (int)(PANEL_WIDTH * edge.first.vertex.x);
            final int cy1 = MARGIN + (int)(PANEL_HEIGHT * edge.first.vertex.y);
            final int cx2 = MARGIN + (int)(PANEL_WIDTH * edge.second.vertex.x);
            final int cy2 = MARGIN + (int)(PANEL_HEIGHT * edge.second.vertex.y);
            
            if (this.solutionEdges.contains(edge)) {
                g.setStroke(THICK_STROKE);
                g.setColor(COLOR_EDGE_SOLUTION);
            } else if (this.visitedEdges.contains(edge)) {
                g.setStroke(MEDIUM_STROKE);
                g.setColor(COLOR_EDGE_VISITED);
            } else {
                g.setStroke(MEDIUM_STROKE);
                g.setColor(COLOR_EDGE);
            }
            
            g.drawLine(
                cx1, cy1, cx2, cy2
            );
        }

        for (int i = 0; i < this.graph.getNodesNum(); i++) {
            final Node node = this.graph.getNode(i);
            
            final int cx = MARGIN + (int)(PANEL_WIDTH * node.vertex.x);
            final int cy = MARGIN + (int)(PANEL_HEIGHT * node.vertex.y);
            
            g.setStroke(MEDIUM_STROKE);

            if (node == this.start) {
                g.setColor(Color.GREEN);
                g.fillOval(
                    (int)(cx - NODE_RADIUS),
                    (int)(cy - NODE_RADIUS),
                    NODE_RADIUS * 2,
                    NODE_RADIUS * 2
                );
                g.setColor(Color.WHITE);
                g.drawOval(
                    (int)(cx - NODE_RADIUS),
                    (int)(cy - NODE_RADIUS),
                    NODE_RADIUS * 2,
                    NODE_RADIUS * 2
                );
            } else if (node == this.end) {
                g.setColor(Color.RED);
                g.fillOval(
                    (int)(cx - NODE_RADIUS),
                    (int)(cy - NODE_RADIUS),
                    NODE_RADIUS * 2,
                    NODE_RADIUS * 2
                );
                g.setColor(Color.WHITE);
                g.drawOval(
                    (int)(cx - NODE_RADIUS),
                    (int)(cy - NODE_RADIUS),
                    NODE_RADIUS * 2,
                    NODE_RADIUS * 2
                );
                
            } else {
                final boolean visited = this.visitedNodes.contains(node); 
                
                if (visited) {
                    g.setColor(COLOR_NODE_VISITED);
                } else {
                    g.setColor(COLOR_NODE);
                }
                g.fillOval(
                    (int)(cx - NODE_RADIUS),
                    (int)(cy - NODE_RADIUS),
                    NODE_RADIUS * 2,
                    NODE_RADIUS * 2
                );
          
                if (visited) {
                    g.setColor(COLOR_NODE_BORDER_VISITED);
                } else {
                    g.setColor(COLOR_NODE_BORDER);
                }
                
                g.drawOval(
                    (int)(cx - NODE_RADIUS),
                    (int)(cy - NODE_RADIUS),
                    NODE_RADIUS * 2,
                    NODE_RADIUS * 2
                );
            }
        }

    }
    
    @Override
    protected void paintComponent(final Graphics g) {
        super.paintComponent(g);
        this.repaintRenderBuffer();
        g.drawImage(this.renderBuffer, 0, 0, null);
    }

    @Override
    public void onUpdate(final Graph graph) {
        if (this.graph == graph) {
            this.repaint();
            if (this.sleep > 0) {
                try {
                    Thread.sleep(this.sleep);
                } catch (InterruptedException e) {}
            }
        }
    }

    public void register(final GraphPanelListener listener) {
        this.listeners.add(listener);
    }

    public void unregister(final GraphPanelListener listener) {
        this.listeners.remove(listener);
    }
    
    synchronized private void notifyNodeSelected(final Node node) {
        for (GraphPanelListener listener : this.listeners) {
            listener.nodeSelected(node);
        }
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        final double x = (double)(e.getX() - MARGIN) / (double)(PANEL_WIDTH);
        final double y = (double)(e.getY() - MARGIN) / (double)(PANEL_HEIGHT);
        final Vector2d p = new Vector2d(x, y);
        
        for (int i = 0; i < this.graph.getNodesNum(); i++) {
            final Node node = this.graph.getNode(i);
            if (Vector2d.dist(node.vertex, p) < NODE_RADIUS_NORM) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        GraphPanel.this.notifyNodeSelected(node);
                    }
                }).start();
            }
        }
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        //
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //
    }

}