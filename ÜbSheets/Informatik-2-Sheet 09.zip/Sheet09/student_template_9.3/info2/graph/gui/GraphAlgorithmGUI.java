package info2.graph.gui;


import javax.swing.JFrame;

import info2.graph.Edge;
import info2.graph.Graph;
import info2.graph.GraphAlgorithm;
import info2.graph.GraphAlgorithmListener;
import info2.graph.Node;

/**
 * This class manages the communication between the GUI and the graph algorithm. Use
 * this class to visualize the graph and the execution process of the graph algorithm.
 *
 * @author Sebastian Otte
 */
public class GraphAlgorithmGUI implements GraphPanelListener, GraphAlgorithmListener {
    
    private Graph graph;
    private GraphAlgorithm algorithm;
    private Node start;
    private Node end;
    
    private GraphPanel panel;
    private final JFrame frame;

    @Override
    public void nodeSelected(final Node node) {
        if (this.end != null) {
            this.start = null;
            this.end = null;
            this.panel.reset();
        } 
        if (this.start == null) {
            this.start = node;
            this.panel.setStart(node);
            this.panel.repaint();
        } else {
            this.end = node;
            this.panel.setEnd(node);
            this.panel.repaint();
            this.algorithm.initialize(this.graph, this.start, this.end);
            this.algorithm.perform(this);
        }
    }
    
    @Override
    public void update() {
        this.panel.onUpdate(this.graph);
    }

    @Override
    public void notifyVisited(final Node node) {
        this.panel.markVisited(node);
    }    
    

    @Override
    public void notifyVisited(final Edge edge) {
        this.panel.markVisited(edge);
        
    }

    @Override
    public void notifySolution(final Edge edge) {
        this.panel.markSolution(edge);
    }
    
    
    public GraphAlgorithmGUI(final Graph graph, final GraphAlgorithm algorithm) {
        this.graph = graph;
        this.algorithm = algorithm;
        
        this.panel = new GraphPanel(graph, 10);
        this.panel.register(this);
        this.frame = new JFrame("Praktische Informatik 2 - Graph Algorithms");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.add(this.panel);
        this.frame.setResizable(false);
        this.frame.pack();
    }
    
    public void show() {
        this.frame.setVisible(true);
    }


}


