package info2.graph.gui;

import info2.graph.Node;

public interface GraphPanelListener {
    public void nodeSelected(final Node node); 
}