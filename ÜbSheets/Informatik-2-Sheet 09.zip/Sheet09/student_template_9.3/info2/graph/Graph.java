package info2.graph;

import info2.graph.tools.DynArray;
import info2.graph.tools.Vector2d;

/**
 * This class represents a undirected (Euclidean) graph. 
 * Each node of the graph is associated with a 2d point on a map.
 * This graph can be seen as a weighted graph: given an edge, we
 * can interpret the length of the edge as a "weight". The length
 * can be calculated by means of the distance between the involved
 * points (their vertices):
 * 
 *  length = Vector2d.dist(node1.vertex, node2.vertex);
 * 
 * This class provides several basic methods to handle the graph,
 * e.g. searching for nodes and edges. You can use indices to 
 * address nodes and edges. 
  *  
 * @author Sebastian Otte
 */
public class Graph {
    
    private DynArray<Node> nodes;
    private DynArray<Edge> edges;

    public Graph() {
        this.nodes = new DynArray<>();
        this.edges = new DynArray<>();
    }
    
    /**
     * Returns the node of the graph that is associated with
     * the given index. Note that the topological order of the
     * nodes within the graph may not be reflected by the nodes' 
     * indices. 
     * 
     * @param i Index of the node of interest.
     * @return Instance of Node or null.
     */
    public Node getNode(final int i) {
        return this.nodes.get(i);
    }
    
    /**
     * Returns the edge of the graph that is associated with
     * the given index.
     * 
     * @param i Index of the edge of interest.
     * @return Instance of Edge or null.
     */
    public Edge getEdge(final int i) {
        return this.edges.get(i); 
    }
    
    /**
     * Returns the associated index of a node or -1 if the node
     * is not part of the graph. 
     * @param node Node of interest.
     * @return Index of the node.
     */
    public int getIndex(final Node node) {
        return this.nodes.find(node);
    }
    
    /**
     * Returns the associated index of an edge or -1 if the edge
     * is not part of the graph. 
     * @param node Node of interest.
     * @return Index of the node.
     */
    public int getIndex(final Edge edge) {
        return this.edges.find(edge);
    }
    
    /**
     * Add a new vertex (wrapped in a Node object) to the graph.
     * The methods return the new index of the added node.
     * @param vertex Instance of Vector2d.
     * @return Index of the new node.
     */
    public int addVertex(final Vector2d vertex) {
        final Node node = new Node(vertex);
        return this.nodes.add(node);
    }
    
    /**
     * Returns the current number of edges within the graph.
     */
    public int getEdgesNum() {
        return this.edges.getSize();
    }
    
    /**
     * Returns the current number of nodes within the graph.
     */
    public int getNodesNum() {
        return this.nodes.getSize();
    }

    /**
     * This methods checks, whether two nodes are linked within this
     * graph. It returns true, if there is an edge that connects the two
     * nodes.
     * @param n1 One node.
     * @param n2 Another node.
     */
    public boolean isLinked(final Node n1, final Node n2) {
        return this.edges.contains(new Edge(n1, n2));
    }
    
    /**
     * Links two nodes within the graph. A new edges is created and 
     * added to both, the graph-global edge arrays and the local
     * node-wise neighbors arrays. The methods return the edge index
     * of the new edge. If there is already a connection between the
     * given nodes, the respective edge index is returned. 
     * 
     * @param first One node.
     * @param second Another node.
     * @return Index of the new edge.
     */
    public int link(final Node first, final Node second) {
        final Edge edge = new Edge(first, second);            
        //
        final int edgeIdx = this.edges.find(edge);
        if (edgeIdx >= 0) {
            //
            // Already connected.
            //
            return edgeIdx;
        }
        //
        // Add edge to global edge-array and local edge-arrays (within the nodes).
        //
        first.edges.add(edge);
        second.edges.add(edge);
        return this.edges.add(edge);
    }
    
    /**
     * Deletes an existing connection between two nodes.
     * 
     * @param first One node.
     * @param second Another node.
     */
    public void delink(final Node first, final Node second) {
        final Edge edge = new Edge(first, second);
        //
        final int edgeIdx = this.edges.find(edge);
        if (edgeIdx >= 0) {
            //
            // Remove from edge arrays.
            //
            this.edges.remove(edgeIdx);
            first.edges.remove(edge);
            second.edges.remove(edge);
        }
    }
    
    
    
    
    
}