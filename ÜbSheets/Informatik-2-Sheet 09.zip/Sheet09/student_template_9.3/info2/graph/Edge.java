package info2.graph;


/**
 * A simple graph edge class. An edge points to two Node instances.
 * The edge is assumed to be undirected. This is realized by means of 
 * the overridden equals methods, which considers two edges e1 and e2 
 * as equal if 
 * 
 *      (e1.first equals e2.first and e1.second equals e2.second)  
 *      
 *          or
 *      
 *      (e1.first equals e2.second and e1.second equals e2.first)  
 * 
 * Thus, the order of first and second is irrelevant in that sense.
 * 
 * Additionally, each edge provides an int variable (tag) and a
 * double variable (value) for additional data storage purposed.
 * 
 * @author Sebastian Otte
 */
public class Edge {
    
    public final Node first;
    public final Node second;
    
    public int tag;
    public double value;
    
    public Edge(final Node first, final Node second) {
        this.first = first;
        this.second = second;
    }
    
    /**
     * Returns the respective other node of the edge or null,
     * if the given node is not part of the edge.
     * @param node An instance of node.
     * @return Possibly, the other node of the edge.
     */
    public Node other(final Node node) {
        if (this.first == node) {
            return second;
        } else if (this.second == node) {
            return first;
        }
        return null;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof Edge) {
            final Edge edge = (Edge)obj;
            //
            if (
                (this.first.equals(edge.first) && this.second.equals(edge.second)) ||
                (this.first.equals(edge.second) && this.second.equals(edge.first))
            ) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override
    public String toString() {
        return first.vertex.toString() + " ---- " + second.vertex.toString();
    }
    
}