package info2.graph.tools;

import java.util.Random;

import info2.graph.Edge;
import info2.graph.Graph;
import info2.graph.Node;

/**
 * This class contains some useful helper methods when
 * dealing with graphs. The methos are mostly used for
 * genering the random graphs for the exercise.
 * 
 * @author Sebastian Otte
 */
public class GraphTools {
    
    /**
     * Return true if x is in the interval [x0, x1].
     * @param x0 Lower bound of the interval.
     * @param x Value of interest.
     * @param x1 Upper bound of the interval.
     */
    private static boolean isBetween(final double x0, final double x, final double x1){
        return (x >= x0) && (x <= x1);
    }

    /**
     * Calculates whether the two line segments intersect.
     * Note: Code adapted from Numeric Recipes.
     */
    private static boolean intersect(Vector2d p1, Vector2d p2, Vector2d p3, Vector2d p4) {
        double x0 = p1.x;
        double y0 = p1.y;
        double x1 = p2.x;
        double y1 = p2.y;
        double a0 = p3.x;
        double b0 = p3.y;
        double a1 = p4.x;
        double b1 = p4.y;
        
        double xy = 0;
        double ab = 0;

        boolean partial = false;
        double denom = (b0 - b1) * (x0 - x1) - (y0 - y1) * (a0 - a1);
        if (denom == 0) {
           xy = -1;
           ab = -1;
        } else {
           xy = (a0 * (y1 - b1) + a1 * (b0 - y1) + x1 * (b1 - b0)) / denom;
           partial = isBetween(0, xy, 1);

           if (partial) {
              ab = (y1 * (x0 - a1) + b1 * (x1 - x0) + y0 * (a1 - x1)) / denom; 
           }
        }
        return (partial && isBetween(0, ab, 1));
    }
    
    /**
     * Checks whether the given edge intersects with another edge within the graph.
     * @param graph Instance of Graph.
     * @param edge Instance of Edge.
     */
    private static boolean intersect(final Graph graph, final Edge edge) {
        for (int i = 0; i < graph.getEdgesNum(); i++) {
            final Edge other = graph.getEdge(i);
            if (
                !edge.first.equals(other.first) &&
                !edge.first.equals(other.second) &&
                !edge.second.equals(other.first) &&
                !edge.second.equals(other.second) &&
                intersect(
                    edge.first.vertex,
                    edge.second.vertex,  
                    other.first.vertex,
                    other.second.vertex
                )
            ) {
                return true;
            }
        }
        return false;
    }
 
    /**
     * Clamps a value to a given range.
     * @param x Value of interest
     * @param lbd Lower bound of the range.
     * @param ubd Upper bound of the range.
     * @return min(max(x, lbd), ubd) 
     */
    private static double clamp(final double x, final double lbd, final double ubd) {
        if (x < lbd) return lbd;
        if (x > ubd) return ubd;
        return x;
    }
    
    /**
     * Calculates the distance between a point and a line segment (edge).
     * @param e Instance of edge.
     * @param p Instance of Vector2d.
     * @return
     */
    private static double distance(final Edge e, final Vector2d p) {
        final Vector2d v = e.first.vertex;
        final Vector2d w = e.second.vertex;
        
        final double l2 = Vector2d.dist2(v, w);
        if (l2 == 0) {
            return Vector2d.dist2(v, p);
        }
        
        final double t = clamp(
            ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2,
            0.0, 1.0
        );
        
        return Vector2d.dist(
            p,
            new Vector2d(v.x + t * (w.x - v.x), v.y + t * (w.y - v.y))
        );
    }
  
    /**
     * Returns whether a point is too close to one of the vertices within
     * the graph, given a tolerated minimal distance.
     * @param graph Instance of Graph.
     * @param vertex Instance of Vector2d.
     * @param minDistance Tolerated minimal distance.
     */
    private static boolean isTooClose(
        final Graph graph, 
        final Vector2d vertex, 
        final double minDistance
    ) {
        for (int i = 0; i < graph.getNodesNum(); i++) {
            final double dist = Vector2d.dist(
                graph.getNode(i).vertex, vertex
            );
            if (dist < minDistance) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns whether an edge is too close to one of the vertices within
     * the graph, given a tolerated minimal distance.
     * @param graph Instance of graph.
     * @param edge Instance of Edge.
     * @param minDistance Tolerated minimal distance.
     */
    private static boolean isTooClose(
        final Graph graph, 
        final Edge edge, 
        final double minDistance
    ) {
        for (int i = 0; i < graph.getNodesNum(); i++) {
            final Node node = graph.getNode(i);
            if (node != edge.first && node != edge.second) {
                final double dist = distance(edge, node.vertex); 
                if (dist < minDistance) {
                    return true;
                }
            }
        }
        return false;  
    }
    
    /**
     * Returns all nodes within the graph that are closer to a node of interest than
     * a given maximal distance.
     * @return Instance of DynArray<Node>.
     */
    private static DynArray<Node> neighbors(
        final Graph graph, 
        final Node node,
        final double maxDistance
    ) {
        final DynArray<Node> nodes = new DynArray<>();
        //
        for (int i = 0; i < graph.getNodesNum(); i++) {
            final Node neighbor = graph.getNode(i); 
            if (
                (neighbor != node) && 
                (Vector2d.dist(node.vertex, neighbor.vertex) < maxDistance)
            ) {
                nodes.add(neighbor);
            }
        }
        //
        return nodes;

    }
    
    /**
     * This methods generates a random graph with a quick-and-dirty brute force
     * procedure.  
     * @param rnd Random number generator.
     * @param vertices Desired number of vertices within th graph.
     * @param width Numerical width of the graph.
     * @param height Numerical height of the graph
     * @param minDistance Tolerated minimal distance between nodes.
     * @return
     */
    public static Graph generateRandomGraph(
        final Random rnd,
        final int vertices,
        final double width,
        final double height,
        final double minDistance
    ) {
        final Graph graph = new Graph();
        
        final int trials = 100;
        //
        // Generate nodes.
        //
        for (int i = 0; i < vertices; i++) {
            for (int t = 0; t < trials; t++) {
                final Vector2d vertex = new Vector2d(
                    rnd.nextDouble() * width,
                    rnd.nextDouble() * height
                );
                if (!isTooClose(graph, vertex, minDistance)) {
                    graph.addVertex(vertex);
                    break;
                }
            }
        }
        //
        // Generate edges.
        //
        for (int i = 0; i < graph.getNodesNum(); i++) {
            final Node node = graph.getNode(i);
            final DynArray<Node> neighbors = neighbors(graph, node, minDistance * 3.0);
            for (int j = 0; j < neighbors.getSize(); j++) {
                final Node neighbor = neighbors.get(j);
                final Edge edge = new Edge(node, neighbor);
                if (
                   !intersect(graph, edge) &&
                   !isTooClose(graph, edge, minDistance * 0.6)
                ) {
                    graph.link(node, neighbor);
                }
            }
        }
        
        return graph;
    }
    
    
    
    
}