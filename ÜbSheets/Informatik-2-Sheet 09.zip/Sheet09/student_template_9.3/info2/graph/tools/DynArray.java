package info2.graph.tools;

/**
 *  This is a generic implementation of the dynamic array from the
 *  lecture (formerly known a DynIntArray) which is now able to handle
 *  different data types.
 *
 * @param <T> The generic parameter T represents the type of the
 * values that are stored in this array.
 *
 * @author Sebastian Otte
 */
public class DynArray<T> {
    
    public static final int INITIAL_CAPACITY = 8;
    private T[] buffer;
    private int size;
    
    public DynArray() {
        this(INITIAL_CAPACITY);
    }

    /**
     * Create an array of elements of the type T.
     * @param <E> The generic parameter.
     * @param capacity Size of the array.
     * @return Instance of E[].
     */
    private static <E> E[] createInstance(final int capacity) {
        //
        // This is one of the ugly hacks one has to deal with sometimes,
        // when using generics in Java. Note that during runtime the type
        // information is gone, which is why we cannot create an array
        // of E directly, but we know that E is changed to Object ...
        //
        // (If you look at the next two lines for too long, you may feel
        // the need to wash your eyes with soap ... or disinfectant ...)
        //
        @SuppressWarnings("unchecked")
        final E[] t = (E[])new Object[capacity];
        return t;
    }
    
    public DynArray(final int initialCapacity) {
        this.buffer = createInstance(initialCapacity);
        this.size = 0;
    }
    
    /**
     * Returns the current of element within the dynamic array. 
     */
    public int getSize() {
        return this.size;
    }
    
    /**
     * Returns the current maximum capacity of the dynamic array.
     * The is increased automatically on demand.
     */
    public int getCapacity() {
        return this.buffer.length;
    }

    /**
     * Increases the internal capacity with a default factor.
     */
    private void increaseCapacity() {
        this.increaseCapacity(Math.max(1, this.buffer.length) * 2);
    }
    
    /**
     * Increases the internal capacity. All previous values are copied
     * into the new array.
     * @param capacity The new capacity.
     */
    private void increaseCapacity(final int capacity) {
        //
        if (capacity <= this.buffer.length) {
            return;
        }
        
        final T[] nextBuffer = createInstance(capacity);
        for (int i = 0; i < this.buffer.length; i++) {
            nextBuffer[i] = this.buffer[i];
        }
        this.buffer = nextBuffer;
    }
    
    /**
     * Adds a new value after the currently last element within the array.
     * If adding the value would exceed the internal capacity, the array's
     * capacity is increased before the insertion.
     * @param value The new value.
     * @return The index of the added value. 
     */
    public int add(final T value) {
        if (this.size >= this.buffer.length) {
            this.increaseCapacity();
        }
        
        final int idx = this.size++;
        this.buffer[idx] = value;
        return idx;
    }
    /**
     * Return the value at index i.
     * @param i Index of the element of interest.
     * @return Instance of T.
     */
    public T get(final int i) {
        return this.buffer[i];
    }

    /**
     * Sets the value at index i. If i is larger than the array's capacity,
     * is it increased by a certain size.  
     * @param i Index of the element of interest.
     * @param value The new value.
     */
    public void set(final int i, final T value) {
        if (i >= this.size) {
            final int capacity = (i + 1) + (this.buffer.length / 2);
            this.increaseCapacity(capacity);
        }
        this.buffer[i] = value;
        this.size = i + 1;
    }
    
    /**
     * Returns true, if the array contains the given value.
     * @param value Instance of T.
     */
    public boolean contains(final T value) {
        if (value == null) {
            return false;
        }
        for (int i = 0; i < this.size; i++) {
            if (this.buffer[i].equals(value)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Returns the index of the given value, if it exists
     * within the array. If the value does not exist, this
     * methods return -1.
     * @param value Element of interest.
     * @return Index of the value in the array.
     */
    public int find(final T value) {
        for (int i = 0; i < this.size; i++) {
            if (this.buffer[i].equals(value)) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Removes a given element from the array (if is exists).
     * @param value Element of interest.
     */
    public void remove(final T value) {
        if (value == null) {
            return;
        }
        
        for (int i = 0; i < this.size; i++) {
            if (this.buffer[i].equals(value)) {
                remove(i);
            }
        }
    }
    
    /**
     * Return the element at index i from the array.
     * @param i Index of the element of interest.
     */
    public void remove(final int i) {
        if ((i < 0) || (i >= this.size)) {
            return;
        }
        //
        for (int j = i; j < (this.size - 1); j++) {
            this.buffer[j] = this.buffer[j + 1];
        }
        this.size--;
    }
    
}