package info2.graph;

/**
 * This interface defined the general structure of a graph algorithm for
 * this exercise. It provides an initialize method (for setup up buffers
 * etc.) and the method perform that shall execute the actual graph
 * algorithm.  
 * 
 * @author Sebastian Otte
 *
 */
public interface GraphAlgorithm  {
    /**
     * This methods will be called to initialize the graph algorithm
     * properly (e.g. buffer 
     * @param graph Graph in which a path shall found.
     * @param start Start node.
     * @param end End node (goal).
     */
    public void initialize(final Graph graph, final Node start, final Node end);
    /**
     * When this method is called the graph algorithm shall be executed. 
     * The result of the path finding procedure shall be marked within the
     * graph directly using the tag-field of the node  
     * 
     * @param listener An instance of GraphAlgorithmListener that is interested
     * in the progress of the algorithm (e.g. to visualize it).
     */
    void perform(final GraphAlgorithmListener listener);
    
}


