package info2.blob;

public class Blob {
    
    public static final int CELL_STATE_FREE = Maze.DEFAULT_CELL_STATE;
    public static final int CELL_STATE_BLOB_FRESH = CELL_STATE_FREE + 1;
    public static final int CELL_STATE_BLOB_DEAD = CELL_STATE_FREE + 2; 
    
    public boolean infest(
        final Maze maze,
        final int x,
        final int y
    ) { 
        //
        // TODO: Implement me.
        //
        return false;
    }
    
}