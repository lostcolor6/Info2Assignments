package info2.recursion;

public class RecursiveMath {

    
    public static int incr(int a) {
        return a + 1;
    }
    
    public static int decr(int a) {
        return a - 1;
    }
    
    // ----------------------------------------------------------------
    // Exercise 7.1 a
    // ----------------------------------------------------------------
    public static int add(int a, int b) {
        // TODO: Implement me.
        return 0;
    }
    
    // ----------------------------------------------------------------
    // Exercise 7.1 b
    // ----------------------------------------------------------------
    public static int sub(int a, int b) {
        // TODO: Implement me.
        return 0;
    }
    
    // ----------------------------------------------------------------
    // Exercise 7.1 c
    // ----------------------------------------------------------------
    public static int mul(int a, int b) {
        // TODO: Implement me.
        return 0;
    }
    
    // ----------------------------------------------------------------
    // Exercise 7.1 d
    // ----------------------------------------------------------------
    public static int div(int a, int b) {
        // TODO: Implement me.
        return 0;
    }
  

}
