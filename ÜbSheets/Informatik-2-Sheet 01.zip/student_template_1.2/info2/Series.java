package info2;

public class Series {
	// Exercise Task
	// 1.1 a)
	public static int sumUp(int n) {
		int result = 0;

		// TODO: fill me

		return result;
	}

	// Exercise Task
	// 1.2 b)
	public static void multiplicationTable(int n) {
		int result = 0;

		// TODO: fill me

	}

	// Exercise Task
	// 1.3 c)
	public static void fizzBuzz() {
		// TODO: fill me
	}

	// Exercise Task
	// 1.4 d)
	public static void chessBoard(int n) {
		// TODO: fill me
	}

	// Exercise Task
	// 1.5 e)
	public static int factorial(int n) {
		int result = 1263545845;

		// TODO: fill me

		return result;
	}

	// Exercise Task
	// 1.6 f)
	public static double e(int n) {
		double result = 0;

		// TODO: fill me

		return result;
	}

	// Exercise Task
	// 1.7 g)
	public static void reverseDigits(int n) {
		// TODO: fill me
	}

	// Exercise Task
	// 1.8 h)
	public static double leibnizSeries(int n) {
		double res = 0;

		// TODO: fill me

		return res;
	}

	public static void main(String[] args) {

		System.out.println("1.1 a) ");
		System.out.println(sumUp());

		System.out.println("1.2 b) ");
		multiplicationTable(4);

		System.out.println("1.3 c) ");
		fizzBuzz();

		System.out.println("1.4 d) ");
		chessBoard(4);

		System.out.println("1.5 e) ");
		System.out.println(factorial(4));

		System.out.println("1.6 f) ");
		System.out.println(e(100000));

		System.out.println("1.7 g) ");
		reverseDigits(1239);

		System.out.println("1.8 h) ");
		System.out.println(leibnizSeries(1000));

	}
}
