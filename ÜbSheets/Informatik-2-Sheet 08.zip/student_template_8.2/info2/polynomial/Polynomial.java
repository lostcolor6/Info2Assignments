package info2.polynomial;

import info2.polynomial.tools.PolynomialParser;

/**
 * A simple list implementation representing polynomials 
 * a recursive structures (linked list).
 * @author Sebastian Otte
 */
public class Polynomial {

    private Monomial head;
    private Polynomial next;    
    
    /**
     * Return this head value of the list.
     * @return Head value as Monomial.
     */
    public Monomial getHead() {
        return this.head;
    }
    
    /**
     * Returns the remaining list. 
     * @return Remaining polynomial.
     */
    public Polynomial getNext() {
        return this.next;
    }
    
    /**
     * Initializes a polynomial with just one Monomial. The remaining
     * list null.
     * @param head Instance of Monomial.
     */
    public Polynomial(final Monomial head) {
        this(head, null);
    }
    
    /**
     * Initializes a polynomial with with a given monomial and
     * another poylnomial (as remaining list). 
     * @param head Instance of Monomial.
     * @param next Instance of Polynomial.
     */
    public Polynomial(final Monomial head, final Polynomial next) {
        this.head = head;
        this.next = next;
    }
    
    /**
     * Returns true if the current polynomial node has a next polynomial node. 
     */
    public boolean hasNext() {
        return this.next != null;
    }
    
    /**
     * Returns the degree of the polynomial, which is the highest degree value
     * of all contained monomials.
     * @return Degree of the polynomial.
     */
    public int degree() {
        if (!this.hasNext()) {
            return this.head.degree;
        }
        return Math.max(this.head.degree, this.next.degree());
    }
    
    /**
     * Creates a copy of the polynomial recursively.
     * @return New polynomial list.
     */
    public Polynomial copy() {
        if (!this.hasNext()) {
            return new Polynomial(this.head);
        }
        return new Polynomial(this.head, this.next.copy());
    }
    
    /**
     * Negates the polynomial, which effectively toogles the signs
     * of the coefficients of all contained monomials. 
     * @return New polynomial list.
     */
    public Polynomial negate() {
        if (!this.hasNext()) {
            return new Polynomial(this.head.negate());
        } else {
            return new Polynomial(this.head.negate(), this.next.negate());
        }
    }
    
    /**
     * Appends all monomials of the given polynomial list (other)
     * at the end of this polynomial. This is a plain list append
     * operation.
     * @param Another polynomial.
     * @return New polynomial list.
     */
    public Polynomial append(final Polynomial other) {
        if (other == null) {
            return this;
            //
            // Alternative:
            //
            //return this.copy();
        } else if (!this.hasNext()) {
            return new Polynomial(this.head, other.copy());
            //
            // Alternative:
            //
            //this.next = other.copy();
            //return this;
        } else {
            return new Polynomial(this.head, this.next.append(other.copy()));
            //
            // Alternative;
            //
            //this.next = this.next.append(other);
            //return this;
        }
    }
    
    private Polynomial dropZerosCore() {
        if (this.head.coefficient.getNumerator() == 0) {
            if (!this.hasNext()) {
                return null;
            } else {
                return this.next.dropZerosCore();
            }
        } else {
            if (!this.hasNext()) {
                return new Polynomial(this.head);
                //
                // Alternative: 
                //
                //return this;
            } else {
                return new Polynomial(
                    this.head,
                    this.next.dropZerosCore()
                );
                //
                // Alternative:
                //
                //this.next = this.next.dropZerosCore();
                //return this;
            }
        }
    }
    
    /**
     * This methods removes all monomials from the polynomial
     * which have a zero coefficient. 
     * @return New polynomial list.
     */
    public Polynomial dropZeros() {
        final Polynomial result = this.dropZerosCore();
        if (result == null) {
            return new Polynomial(new Monomial(0, 0));
        }
        return result;
    }
    
    @Override
    public String toString() {
        if (!this.hasNext()) {
            return this.head.toString();
        } else {
            return this.head.toString() + " + " + this.next.toString();
        }
    }
    
    private boolean equalsHelper(final Polynomial other) {
        if (other == null) {
            return false;
        } else if (this.hasNext() != other.hasNext()) {
            return false;
        } else if (!this.hasNext()) {
            return this.head.equals(other.head);
        } else {
            return this.head.equals(other.head) && this.next.equalsHelper(other.next);
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Polynomial) {
            return equalsHelper((Polynomial)obj);
        }
        return false;
    }
    
    // ----------------------------------------------------------------
    // Exercise 2 (a)
    // ----------------------------------------------------------------
    
    public boolean isSorted() {
        //
        // TODO: Implement me.
        //        
        return false;
    }

    // ----------------------------------------------------------------
    // Exercise 2 (b)
    // ----------------------------------------------------------------

    public Polynomial insertSorted(final Monomial m) {
        //
        // TODO: Implement me.
        //        
        return null;
    }

    // ----------------------------------------------------------------
    // Exercise 2 (c)
    // ----------------------------------------------------------------
    
    public Polynomial sort() {
        //
        // TODO: Implement me.
        //        
        return null;
    }
    
    // ----------------------------------------------------------------
    // Exercise 2 (d)
    // ----------------------------------------------------------------
    
    public Polynomial simplify() {
        //
        // TODO: Implement me.
        //        
        return null;
    }
    
    // ----------------------------------------------------------------
    // Exercise 2 (e)
    // ----------------------------------------------------------------

    public Polynomial sub(final Polynomial other) {
        return this.add(other.negate());
    }

    public Polynomial add(final Polynomial other) {
        //
        // TODO: Implement me.
        //        
        return null;
    }
    
    // ----------------------------------------------------------------
    // Exercise 2 (f)
    // ----------------------------------------------------------------
    
    public Polynomial mul(final Polynomial other) {
        //
        // TODO: Implement me.
        //        
        return null;
    }
    
    
    // ----------------------------------------------------------------
    // Exercise 3
    // ----------------------------------------------------------------
    
    public Polynomial[] div(final Polynomial other) {
        //
        // TODO: Implement me.
        //        
        return null;
    }
    
    public static void main(String[] args) {
        Polynomial p = PolynomialParser.parse("5x^2 + 1");
        Polynomial q = PolynomialParser.parse("4x^5 + 2x^4 +  1x^3 + 1/2x^2 + 1/4x^1 + 1/8x^0");
        
        System.out.println(p);
        System.out.println(q);
        
        System.out.println();
        
        System.out.println(PolynomialParser.parse("1"));
        System.out.println(PolynomialParser.parse("x"));
        System.out.println(PolynomialParser.parse("x^2 - x"));
        System.out.println(PolynomialParser.parse("5x^2 + 1"));
        
    }
    
}