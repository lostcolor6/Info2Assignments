package info2.list;

import org.junit.Assert;

import org.junit.Test;


public class IntListTest {
    
    public static IntList cons(final int ...values) {
        
        final IntList list = new IntList();
        for (int i = 0; i < values.length; i++) {
            list.addBack(values[i]);
        }
        return list;
    }
    
    @Test
    public void testFind() {
        Assert.assertEquals(cons(1,2,3,4).find(1), 0);
        Assert.assertEquals(cons(1,2,3,4).find(2), 1);
        Assert.assertEquals(cons(1,2,3,4).find(3), 2);
        Assert.assertEquals(cons(1,2,3,4).find(4), 3);
        Assert.assertEquals(cons(1,2,3,4).find(5), -1);
        Assert.assertEquals(new IntList().find(0), -1);
    }
    
    @Test
    public void testMin() {
        Assert.assertEquals(cons(1,2,3,4).min(), 1);
        Assert.assertEquals(cons(4,3,2,1).min(), 1);
        Assert.assertEquals(cons(4,3,0, 2,1).min(), 0);
        Assert.assertEquals(new IntList().min(), IntList.INVALID);
    }

    @Test
    public void testMax() {
        Assert.assertEquals(cons(1,2,3,4).max(), 4);
        Assert.assertEquals(cons(4,3,2,1).max(), 4);
        Assert.assertEquals(cons(4,3,8,2,1).max(), 8);
        Assert.assertEquals(new IntList().max(), IntList.INVALID);
    }

    
    private void assertEquals(final int[] a, final int[] b) {
        Assert.assertEquals(a.length, b.length);
        for (int i = 0; i < a.length; i++) {
            Assert.assertEquals(a[i], b[i]);
        }
    }
    
    @Test
    public void testAsArray() {
        assertEquals(cons().asArray(), new int[]{});
        assertEquals(cons(1).asArray(), new int[]{1});
        assertEquals(cons(2).asArray(), new int[]{2});
        assertEquals(cons(1,2,3,4).asArray(), new int[]{1,2,3,4});
        assertEquals(cons(1,2,3,4).asArray(), new int[]{1,2,3,4});
        assertEquals(
            cons(1,2,3,4,0,0,0,0,0,0,0,0,0,0,0).asArray(), 
            new int[]{1,2,3,4,0,0,0,0,0,0,0,0,0,0,0}
        );
    }
    
    private IntList remove(final IntList list, final int i) {
        list.remove(i);
        return list;
    }

    private IntList reverse(final IntList list) {
        list.reverse();
        return list;
    }

    @Test
    public void testRemove() {
        assertEquals(remove(cons(), 0).asArray(), new int[]{});
        assertEquals(remove(cons(1), 0).asArray(), new int[]{});
        assertEquals(remove(cons(1,2,3,4), 0).asArray(), new int[]{2, 3, 4});
        assertEquals(remove(cons(1,2,3,4), 1).asArray(), new int[]{1, 3, 4});
        assertEquals(remove(cons(1,2,3,4), 2).asArray(), new int[]{1, 2, 4});
        assertEquals(remove(cons(1,2,3,4), 3).asArray(), new int[]{1, 2, 3});
        assertEquals(remove(cons(1,2,3,4), -1).asArray(), new int[]{1, 2, 3, 4});
        assertEquals(remove(cons(1,2,3,4), 4).asArray(), new int[]{1, 2, 3, 4});
    }
    
    @Test
    public void testReverse() {
        assertEquals(reverse(cons()).asArray(), new int[]{});
        assertEquals(reverse(cons(1)).asArray(), new int[]{1});
        assertEquals(reverse(cons(1,2)).asArray(), new int[]{2,1});
        assertEquals(reverse(cons(2,3,4)).asArray(), new int[]{4,3,2});
        assertEquals(reverse(cons(1,2,3,4)).asArray(), new int[]{4,3,2,1});
        assertEquals(reverse(reverse(cons(1,2,3,4))).asArray(), new int[]{1, 2, 3, 4});
    }
    
    
    
}

