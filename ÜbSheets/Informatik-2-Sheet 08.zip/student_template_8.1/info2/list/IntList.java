package info2.list;

public class IntList {

    public static final int INVALID = Integer.MIN_VALUE;
    
    private IntListNode front; 
    
    public IntList() {
        this.front = null;
    }
    /**
     * Returns true if the list is empty.
     */
    public boolean isEmpty() {
        return this.front == null;
    }
    
    /**
     * Inserts a value at the front of list.
     * @param value The value that is to be inserted. 
     */
    public void addFront(final int value) {
        this.front = new IntListNode(value, this.front);
    }
    
    /**
     * Recursive helper method that traverses through a list inserts a new
     * node at the very end.
     * @param ptr Current list node.
     * @param value The value that is to be inserted.
     */
    private static void addBackHelper(final IntListNode ptr, final int value) {
        if (ptr.hasNext()) {
            addBackHelper(ptr.next, value);
        } else {
            ptr.next = new IntListNode(value);
        }
    }
    
    /**
     * Inserts a value at the end of the list.
     * @param value The value that is to be inserted.
     */
    public void addBack(final int value) {
        if (this.isEmpty()) {
            this.addFront(value);
        } else {
            addBackHelper(this.front, value);
        }
    }
    
    /**
     * Calculates (iteratively) the number of element within
     * the list.
     * @return Number of list elements/nodes.
     */
    public int size() {
        int ctr = 0;
        
        IntListNode ptr = this.front;
        
        while (ptr != null) {
            ctr++;
            ptr = ptr.next;
        }
        
        return ctr;
    }
    
    /**
     * Recursive helper method for get.
     * @param ptr Current list node.
     * @param i Index of the element that is to be returned.
     * @return Value at index i or INVALID.
     */
    private static int getHelper(final IntListNode ptr, int i) {
        if (ptr == null) {
            return INVALID;
        } else if (i == 0) {
            return ptr.value;
        }
        return getHelper(ptr.next, i-1);
    }
    /**
     * Recursive variant of the get method. Returns the i-th element
     * within the list or INVALID if the i-th element does not exist.
     * @param i Index of the element that is to be returned.
     * @return Value at index i or INVALID.
     */
    public int get(final int i) {
        return getHelper(this.front, i);
    }
    
    /**
     * Own implementation of the toString-method. This method will be
     * used automatically whenever an instance of IntList is, e.g., 
     * concatenated with a string.
     */
    @Override
    public String toString() {
        final StringBuilder out = new StringBuilder();
        IntListNode ptr = this.front;
        
        while (ptr != null) {
            out.append(ptr.value);
            if (ptr.hasNext()) {
                out.append(", ");
            }
            ptr = ptr.next;
        }
        
        return out.toString();
    }
        
    // ----------------------------------------------------------------
    // Exercise 1 (a)
    // ----------------------------------------------------------------
    
   
    public int find(final int value) {
        //
        // TODO: Implement me.
        //
        return -1;
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (b)
    // ----------------------------------------------------------------
    
    public int min() {
        //
        // TODO: Implement me.
        //
        return INVALID;
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (c)
    // ----------------------------------------------------------------
    
    public int max() {
        //
        // TODO: Implement me.
        //
        return INVALID;
    }

    // ----------------------------------------------------------------
    // Exercise 1 (d)
    // ----------------------------------------------------------------

    public int[] asArray() {
        //
        // TODO: Implement me.
        //
        return null; 
    }    

    // ----------------------------------------------------------------
    // Exercise 1 (e)
    // ----------------------------------------------------------------
    
    public void remove(final int i) {
        //
        // TODO: Implement me.
        //
    }
    
    // ----------------------------------------------------------------
    // Exercise 1 (f)
    // ----------------------------------------------------------------

    public void reverse() {
        //
        // TODO: Implement me.
        //
    }

}
