package info2.polynomial;

import org.junit.Assert;
import org.junit.Test;

import info2.polynomial.tools.PolynomialParser;

public class PolynomialDivTest {

    private static Polynomial poly(final String str) {
        return PolynomialParser.parse(str);
    }
    
    private Polynomial[] pair(final Polynomial p, final Polynomial r) {
        return new Polynomial[] {p, r};
    }
        
    private Polynomial notNull(final Polynomial p) {
        if (p == null) {
            return new Polynomial(Monomial.ZERO); 
        }
        return p;
    }
    
    private boolean equals(final Polynomial[] p, final Polynomial[] q) {
        p[0] = notNull(p[0]);
        p[1] = notNull(p[1]);
        q[0] = notNull(q[0]);
        q[1] = notNull(q[1]);
        //
        return p[0].equals(q[0]) && p[1].equals(q[1]);
    }

    @Test
    public void testDiv() {
        
        Assert.assertTrue(
            equals(
                poly("3x^3 + 2x^2 + x").div(poly("1")),
                pair(poly("3x^3 + 2x^2 + x"), null)
            )
        );
        Assert.assertTrue(
            equals(
                poly("-6x^3 + 5x^2 + 14x - 12").div(poly("-2x + 3")),
                pair(poly("3x^2 + 2x - 4"), null)
            )
        );
        Assert.assertTrue(
            equals(
                poly("x^3 + 3x^2 - 6x - 8").div(poly("x - 2")),
                pair(poly("x^2 + 5x + 4"), null)
            )
        );
        Assert.assertTrue(
            equals(
                poly("x^3 + 3x^2 - 6x - 8").div(poly("x - 1")),
                pair(poly("x^2 + 4x - 2"), poly("-10"))
            )
        );
        Assert.assertTrue(
            equals(
                poly("x^3 - x^2 - 5x + 6").div(poly("x - 2")),
                pair(poly("x^2 + x - 3"), null)
            )
        );
        //
        // 3x^5 + 9x^4 + 8x^3 + 2x^2 + 8 : 3x^3 + 3x^2 - 4x + 4
        // = x^2 + 2x + 2
        //
        Assert.assertTrue(
            equals(
                poly("3x^5 + 9x^4 + 8x^3 + 2x^2 + 8").div(poly("3x^3 + 3x^2 - 4x + 4")),
                pair(poly("x^2 + 2x + 2"), null)
            )
        );
        //
        // 2x^5 - 2x^4 + 7x^3 - 14x^2 + 3x - 9 : x^3 - x^2 + 3x - 4
        // = 2x^2 + 1, rest = - (5x^2 + 5) 
        //
        Assert.assertTrue(
            equals(
                poly("2x^5 - 2x^4 + 7x^3 - 14x^2 + 3x - 9").div(poly("x^3 - x^2 + 3x - 4")),
                pair(poly("2x^2 + 1"), poly("-5x^2 - 5"))
            )
        );
    }
    
}
